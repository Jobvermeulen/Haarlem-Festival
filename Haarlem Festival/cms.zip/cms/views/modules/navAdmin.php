<nav class='page_section'>
    <img src="../../images/logo.png" alt="Haarlem Festival Logo" />
    <a <?php if($active == 'Home' || $active == '' || $active == 'Homepage') { echo'class="active"'; }?> href="/home">HOME</a>
    <a <?php if($active == 'Jazz') { echo'class="active"'; }?> href="/home?page=Jazz">JAZZ</a>
    <a <?php if($active == 'Dance') { echo'class="active"'; }?> href="/home?page=Dance">DANCE</a>
    <a <?php if($active == 'Food') { echo'class="active"'; }?> href="/home?page=Food">FOOD</a>
    <a <?php if($active == 'Historic') { echo'class="active"'; }?> href="/home?page=Historic">HISTORIC</a>
    <section class="right">
        <a <?php if($active == 'volunteers') { echo'class="active"'; }?> href="/volunteers">VOLUNTEERS</a>
        <a <?php if($active == 'tickets') { echo'class="active"'; }?> href="/logout">SIGNOUT</a>
    </section>
</nav>