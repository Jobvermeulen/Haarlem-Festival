<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="Group 5 Development">
<link href="css/main.css?version=<?php echo date('Y-m-d-H-i-s', filemtime('css/main.css')) ?>" rel="stylesheet">
<link href="css/nav.css?version=<?php echo date('Y-m-d-H-i-s', filemtime('css/nav.css')) ?>" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.js"></script>
<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=djmubzy00ktmozvm4cdshj1ipiansuq5o3x0kgnw7e0007ph"></script>
<script src='js/main.js?$$REVISION$$'></script>
