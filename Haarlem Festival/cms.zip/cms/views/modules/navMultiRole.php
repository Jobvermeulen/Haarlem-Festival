    <!-- Navigation -->
<nav class='page_section'>
    <img src="../../images/logo.png" alt="Haarlem Festival Logo" />
    <a <?php if($active == 'Home' || $active == '' || $active == 'Homepage') { echo'class="active"'; }?> href="/home">HOME</a>
    <?php
        //Foreach role in roles check which role to add to the menu bar
        foreach($_SESSION['roles'] as $role)
        {
            switch($role)
            {
                case 'Jazz':
                    ?><a <?php if($active == 'Jazz') { echo'class="active"'; }?> href="/home?page=Jazz">JAZZ</a><?php
                break;
                case 'Dance':
                    ?><a <?php if($active == 'Dance') { echo'class="active"'; }?> href="/home?page=Dance">DANCE</a><?php
                break;
                case 'Food':
                    ?><a <?php if($active == 'Food') { echo'class="active"'; }?> href="/home?page=Food">FOOD</a><?php
                break;
                case 'Historic':
                    ?><a <?php if($active == 'Historic') { echo'class="active"'; }?> href="/home?page=Historic">HISTORIC</a><?php
                break;
                default:
                    echo 'You dont have roles contact your admin';
                break;
            }
        }

    ?>
    <section class="right">
        <a <?php if($active == 'tickets') { echo'class="active"'; }?> href="/logout">SIGNOUT</a>
    </section>
</nav>
