<!DOCTYPE html>
<html lang="en">
    <?php
        //Start session
        session_start();
    ?>
<head>
    <?php
    //Load the head
    $controller = new baseController();
    $controller->loadHead();
    ?>  
    <title>Haarlem Festival - Error 404</title>
</head>

<body>
    <?php
    // Load the menu
    $controller->loadMenu("index");
    ?>

    <div>
        <div>
            <div>
                <h1>Oops</h1>
                <h1>We can't find the page you are looking for.</h1>
                <p><strong>Error code: 404</strong></p>
                <p>Go to <a href="/">login</a> page</p>

            </div>
        </div>
    </div>
</body>
</html>
