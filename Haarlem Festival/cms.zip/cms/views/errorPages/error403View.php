<!DOCTYPE html>
<html lang="en">
    <?php
        //Start session
        session_start();
    ?>
<head>
    <?php
    //Load the head
    $controller = new baseController();
    $controller->loadHead();
    ?>  
    <title>Haarlem Festival - Error 403</title>
</head>

<body>
    <?php
    // Load the menu
    $controller->loadMenu("index");
    ?>

    <div>
        <div>
            <div>
                <h1>Oops</h1>
                <h1>You dont have permission to access this page.</h1>
                <p>Please try another page!</p>
                <p><strong>Error code: 403</strong></p>
            </div>
        </div>
    </div>
</body>
</html>
