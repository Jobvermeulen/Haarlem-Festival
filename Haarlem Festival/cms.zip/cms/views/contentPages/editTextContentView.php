<!DOCTYPE html>
<html lang="en">
    <?php
        //Start session
        session_start();
        //Create content cotroller/model
        $model = new contentModel();
        $controller = new contentController($model);

        $pageName;
        //Check if page is in url
        if($_GET['page'])
        {
            $pageName = strip_tags($_GET['page']);
        }

        //Check if user is signedIN and has admin role
        $controller->checkSignedIn();
        if($pageName != 'Homepage')
        {
            $controller->checkRole($pageName);
        }

        //Check if volunteerID is in url and if it is numeric
        if(isset($_GET['contentID']) && is_numeric($_GET['contentID']))
        {
            //Create variable with ID from URL and get data with that ID
            $contentID = strip_tags($_GET['contentID']);
            $text = $controller->doGetTextContentByID($contentID, $pageName);
            
            //Check for server request method POST and update text in database
            if($_SERVER["REQUEST_METHOD"] == "POST") {
                $error = $controller->doUpdateTextContent($_POST, $contentID, $pageName);
            }
        }
        else { //Go to homepage
            header('Location: /home');
        }
        
    ?>
<head>
    <?php
    //Load the head
    $controller->loadHead();
    ?>  
    <title>CMS Haarlem Festival - Edit Text Content</title>
    <script type="text/javascript">
        tinymce.init({
            selector: 'textarea',
            plugin: 'a_tinymce_plugin'
        });
    </script>
</head>

<body>
    <?php
    // Load the menu
    $controller->loadMenu("volunteers");
    ?>

    <article class="container">
        <h1 class="mb-0">Edit Text Content</h1>
        <form id="editText" class="editEvent" method="POST" action="">
            <p class="danger"><?php if(isset($error['basicError'])) { echo $error['basicError']; } ?></p>
            <section class="event">
                <label for="username">Text Name:</label>
                <input class="input" size="25" type="text" id="event" name="username" value="<?php echo $text->GetName(); ?>" disabled autofocus>
                <button class="btn btn-primary btn-editEvent btn-gray" type="submit">SAVE</button>
                <button class="btn btn-primary btn-editEvent btn-gray" type="button" onclick="cancelMessage('editText', 'content?page=<?php echo $pageName; ?>')">CANCEL</button>
            </section>
            <section class="event">
                <p>Text:</p>
                <textarea rows="10" name="text" required><?php echo $text->getText(); ?></textarea>
            </section>
        </form>
    </article>
</body>
</html>
