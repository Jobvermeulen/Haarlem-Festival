<!DOCTYPE html>
<html lang="en">
    <?php
        //Start session
        session_start();
        //Create content cotroller/model
        $model = new contentModel();
        $controller = new contentController($model);

        $pageName;
        
        //Check if page is in url
        if(isset($_GET['page']))
        {
            $pageName = strip_tags($_GET['page']);
        }

        //Check if user is signedIN and has a specific role
        $controller->checkSignedIn();
        //If pagename if not homepage
        if($pageName != 'Homepage')
        {
            $controller->checkRole($pageName);
        }

        //Check if contenID is in url and if it is numeric
        if(isset($_GET['contentID']) && is_numeric($_GET['contentID']))
        {
            //Create variable with ID from URL and get data with that ID
            $contentID = strip_tags($_GET['contentID']);
            $image = $controller->doGetImageContentByID($contentID, $pageName);
            
            //Check for server request method POST and update the data that was filled in in the form
            if($_SERVER["REQUEST_METHOD"] == "POST") {
                $error = $controller->doUpdateImageContent($_POST, $contentID, $pageName, $_FILES['image'], $image->getImage());
            }
        }
        else { //Go to homepage
            header('Location: /home');
        }
        
    ?>
<head>
    <?php
    //Load the head
    $controller->loadHead();
    ?>  
    <title>CMS Haarlem Festival - Edit Image Content</title>
</head>

<body>
    <?php
    // Load the menu
    $controller->loadMenu("volunteers");
    ?>

    <article class="container">
        <h1 class="mb-0">Edit Image Content</h1>
        <form id="editImage" class="editEvent" method="POST" action="" enctype="multipart/form-data">
            <p class="danger"><?php if(isset($error['basicError'])) { echo $error['basicError']; } ?></p>
            <section class="event">
                <label for="username">Name:</label>
                <input class="input" size="25" type="text" id="event" name="username" value="<?php echo $image->GetName(); ?>" disabled autofocus>
                <button class="btn btn-primary btn-editEvent btn-gray" type="submit">SAVE</button>
                <button class="btn btn-primary btn-editEvent btn-gray" type="button" onclick="cancelMessage('edit<?php echo $pageName?>', 'content?page=<?php echo $pageName; ?>')">CANCEL</button>
            </section>
            <section class="event">
                <label for="password">Alt Text:</label>
                <input class="input" type="text" id="altText" name="altText" value="<?php echo $image->GetAltText(); ?>" required>
            </section>
            <section class="event">
                <label class="mb-19px"> Image (max 4mb):</label>
                <input type="file" class="custom-file-input" name="image" id="image" accept="image/*" onclick="fileSize(event);"/>
                <img id="showImage" width="248px" height="140px" style="vertical-align: middle;" src="https://haarlem-festival.nl/<?php echo $image->getImage(); ?>">
            </section>
        </form>
        <form id="deleteVolunteer" method="POST" action="">
            <input type="hidden" name="action" value="delete"/>
        </form>
    </article>
</body>
</html>
