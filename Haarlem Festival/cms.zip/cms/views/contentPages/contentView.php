<!DOCTYPE html>
<html lang="en">
    <?php
        //Start session
        session_start();
        //Set pagename and get page from url
        $pageName;
        if(isset($_GET['page']))
        {   //Strip tags from page
            $pageName = strip_tags($_GET['page']);
            //Check if pageName is not one of below
            if($pageName != 'Jazz' && $pageName != 'Dance' && $pageName != 'Food' && $pageName != 'Historic' && $pageName != 'Homepage' )
            {   //Go to error page
                header('Location: /error404');
            }
        }
        else { //Go to error page
            header('Location: /error404');
        }
        //Create new contentModel and controller
        $model = new contentModel();
        $controller = new contentController($model);

        //Check if user is signedin and is an Admin
        $controller->checkSignedIn();
        if($pageName != 'Homepage')
        {
            $controller->checkRole($pageName);
        }
        //Get text and image content
        $text = $controller->doGetTextContent($pageName);
        $images = $controller->doGetImagesContent($pageName);
    ?>
<head>
    <?php
    //Load the head
    $controller->loadHead();
    ?>  
    <title>CMS Haarlem Festival - <?php echo $pageName?> Content</title>
</head>

<body>
    <?php
    // Load the menu
    $controller->loadMenu($pageName);
    ?>

    <article class="container programme">
        <h1 class="mb-0">Manage <?php echo $pageName?> Content</h1>
            <section class="width100 mt-26">
                <h2 class="m-10"><?php echo $pageName?> Content</h2>
                <h3 class="m-10">Text</h3>
            </section>
            <section class="width100 row">
                <table class="hfTable">
                    <tr>
                        <th class="hfthWidth">ContentID</th>
                        <th>Name</th>
                        <th>Text</th>
                        <th>Edit</th>
                    </tr>
                    <?php
                    //Foreach that echo's all text content
                    foreach($text as $content)
                    {
                        echo '
                                <tr>
                                    <td>'. $content->getID() .'</td>
                                    <td>'. $content->getName() .'</td>
                                    <td>'. substr($content->getText(), 0, 100) .'...</td>
                                    <td><a href="editText?contentID='. $content->getID() .'&page='. $pageName .'">Edit text</a></td>
                                </tr>
                        ';
                    }
                    ?>
                </table>
            </section>
            <section class="width100 mt-26">
                <h3 class="m-10">Images</h3>
            </section>
            <section class="width100 mpb row">
                <table class="hfTable">
                    <tr>
                        <th class="hfthWidth">ContentID</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Edit</th>
                    </tr>
                    <?php
                    //Foreach that echo's all image content
                    foreach($images as $image)
                    {
                        echo '
                                <tr>
                                    <td>'. $image->getID() .'</td>
                                    <td>'. $image->getName() .'</td>
                                    <td><img id="showImage" width="248px" height="140px" style="vertical-align: middle;" src="https://haarlem-festival.nl/'. $image->getImage().'"></td>
                                    <td><a href="editImage?contentID='. $image->getID() .'&page='. $pageName .'">Edit image</a></td>
                                </tr>
                        ';
                    }
                    ?>
                </table>
            </section>
    </article>
</body>
</html>