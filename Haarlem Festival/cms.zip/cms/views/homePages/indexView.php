<!DOCTYPE html>
<html lang="en">
    <?php
        //Starts session and makes an empty pageName variable
        session_start();
        $pageName = '';
        //Check if page is in url
        if(isset($_GET['page']))
        {
            //Script tags and set in $pageName
            $pageName = strip_tags($_GET['page']);
            //Check if name is not like festival names and go to error page
            if($pageName != 'Jazz' && $pageName != 'Dance' && $pageName != 'Food' && $pageName != 'Historic')
            {
                header('Location: /error404');
            }
        }
        //Create ticketModel and controller
        $model = new salesModel();
        $controller = new salesController($model);
        //Check if user is signedin and is a volunteer or Admin
        $controller->checkSignedIn();
        if($pageName != '')
        {
            $controller->checkRole($pageName);
        }
        //Get data of all the time and get data of last week
        $dataTotal = $controller->doGetTicketAndCustomerData($pageName);
        $dataWeek = $controller->doGetWeeklyTAndCData($pageName);
    ?>
<head>
    <?php
    //Load the head
    $controller->loadHead();
    ?>  
    <title>CMSHaarlem Festival - <?php echo $pageName?> </title>
</head>

<body>
    <?php
    // Load the menu
    $controller->loadMenu($pageName);
    ?>
    <article class="container dashboard">
        <section class="row">
            <section class="width50 boxH">
                <h1><?php echo $pageName?> Tickets Sold</h1>
                <section class="row">
                    <section class="width50">
                        <p><strong>Total</strong></p>
                        <p class="text-center big"><?php if(isset($dataTotal['soldQuantity'])) { echo $dataTotal['soldQuantity']; } else { echo 0; } ?></p>
                    </section>
                    <section class="width50">
                        <p><strong>This Week</strong></p>
                        <p class="text-center big"><?php if(isset($dataWeek['quantity'])) { echo $dataWeek['quantity']; } else { echo 0; } ?></p>
                    </section>
                </section>
            </section>
            <section class="width25 text-center boxH">
                <h1><?php echo $pageName?> Programme</h1>
                <section class="width100">
                    <?php
                        //2 Views if pageName = '' then it is the home page
                        if($pageName == '')
                        {
                            ?>
                                <p><strong>No programme to edit for the HomePage</strong></p>
                            <?php
                        }
                        else {
                            ?>
                            <p><strong>Go here if you want to change programme</strong></p>
                            <br/>
                            <a class="btn btn-primary" href="/programme?page=<?php echo $pageName?>">Manage Programme</a>
                            <?php
                        }
                    ?>
                </section>
            </section>
            <section class="width25 text-center boxH">
                <h1><?php echo $pageName?> Content</h1>
                <section class="width100">
                    <?php
                        //2 Views if pageName = '' then it is the home page
                        if($pageName == '')
                        {
                            ?>
                                <p><strong>Go here if you want to change content from the HomePage</strong></p>
                                <br/>
                                <a class="btn btn-primary" href="/content?page=Homepage">Manage Content</a>
                            <?php
                        }
                        else {
                            ?>
                                <p><strong>Go here if you want to change content</strong></p>
                                <br/>
                                <a class="btn btn-primary" href="/content?page=<?php echo $pageName; ?>">Manage Content</a>
                            <?php
                        }
                    ?>
                </section>
            </section>
        </section>
        <section class="row">
            <section class="width50 boxH">
                <h1><?php echo $pageName?> Customers</h1>
                <section class="row">
                    <section class="width50">
                        <p><strong>Total</strong></p>
                        <p class="text-center big"><?php if(isset($dataTotal['customers'])) { echo $dataTotal['customers']; } else { echo 0; } ?></p>
                    </section>
                    <section class="width50">
                        <p><strong>This Week</strong></p>
                        <p class="text-center big"><?php if(isset($dataWeek['customers'])) { echo $dataWeek['customers']; } else { echo 0; } ?></p>
                    </section>
                </section>
            </section>
            <section class="width25 boxH">
                <h1><?php echo $pageName?> Website Visitors</h1>
                <section class="width100">
                    <p><strong>Total</strong></p>
                    <p class="text-center big"><?php echo $controller->showCounter($pageName); ?></p>
                </section>
            </section>
            <section class="width25 boxH">
                <h1><?php echo $pageName?> Revenue</h1>
                <section class="width100">
                        <p><strong>This Week</strong></p>
                        <p class="text-center big">€<?php if(isset($dataWeek['revenue'])) { echo number_format($dataWeek['revenue'], 2); } else { echo 0; } ?></p>
                    </section>
            </section>
        </section>
        <section class="row">
            <section class="width25 bigBoxH">
                <h1><?php echo $pageName?> Tickets</h1>
                <canvas class="text-center" id="soldChart" width=50 height="50"></canvas>
                <p class="text-center">Total Revenue</p>
                <p class="text-center">€ <?php if(isset($dataTotal['revenue'])) { echo number_format($dataTotal['revenue'], 2); } ?></p>
                <p class="text-center">Tickets</p>
                <p class="text-center"><?php if(isset($dataTotal['soldQuantity'],$dataTotal['totalQuantity'])) { echo $dataTotal['soldQuantity'] ."/". $dataTotal['totalQuantity']; } ?></p>
                <a class="buttonSales row btn btn-primary" href="/sales?page=<?php echo $pageName?>">Check Sales</a>
            </section>
            <section class="width75 bigBoxH">
                <h1><?php echo $pageName?> Daily Sales</h1>
                <canvas class="text-center" id="dailySales" width="300" height="145"></canvas>
                <section class="row">
                    <a class="buttonSales2 btn btn-primary" href="/csvDownload">Download Ticket Availability CSV</a>
                    <a class="buttonSales2 btn btn-primary" href="/csvDownloadPerDay">Download Sales Per Day CSV</a>
                </section>
            </section>
        </section>
    </article>
    <script type = "text/JavaScript">
        var pageName = "<?php echo $pageName?>";
        getSalesAvailableChart(pageName);
        getDailySalesChart(pageName);
    </script>
</body>
</html>
