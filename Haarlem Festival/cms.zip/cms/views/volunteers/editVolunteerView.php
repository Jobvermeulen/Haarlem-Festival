<!DOCTYPE html>
<html lang="en">
    <?php
        //Start session
        session_start();
        //Create volunteer cotroller/model
        $model = new volunteerModel();
        $controller = new volunteerController($model);

        //Check if user is signedIN and has admin role
        $controller->checkSignedIn();
        $controller->checkAdminRole();

        //Check if volunteerID is in url and if it is numeric
        if(isset($_GET['volunteerID']) && is_numeric($_GET['volunteerID']))
        {
            //Create variable with ID from URL and get data with that ID
            $volunteerID = strip_tags($_GET['volunteerID']);
            $volunteer = $controller->doGetVolunteerByID($volunteerID);
            
            //Check for server request method POST and check if action is set and not empty
            if($_SERVER["REQUEST_METHOD"] == "POST") {
                if(isset($_POST['action']) && !empty($_POST['action'])) {
                    //Check if action is update or delete
                    if($_POST['action'] == 'update')
                    {
                        //Updates controller, if error messages appear, they will return here
                        $error = $controller->doUpdateVolunteerByID($volunteerID, $_POST, $volunteer->getEmail());
                    }
                    elseif($_POST['action'] == 'delete')
                    {
                        //Try to delete the volunteer
                        $controller->doDeleteVolunteer($volunteerID);
                    }
                }
                else { //Set error
                    $error['basicError'] = 'Not everything is filled in';
                }
            }
        }
        else { //Go back to volunteer page
            header('Location: /volunteers');
        }
        
    ?>
<head>
    <?php
    //Load the head
    $controller->loadHead();
    ?>  
    <title>CMS Haarlem Festival - Edit Volunteer</title>
</head>

<body>
    <?php
    // Load the menu
    $controller->loadMenu("volunteers");
    ?>

    <article class="container">
        <h1 class="mb-0">Volunteers</h1>
        <form id="editVolunteer" class="editEvent" method="POST" action="">
            <p class="danger"><?php if(isset($error['basicError'])) { echo $error['basicError']; } ?></p>
            <section class="event">
                <label for="username">Username:</label>
                <input class="input" size="25" type="text" id="event" name="username" value="<?php echo $volunteer->getUsername(); ?>" disabled required autofocus>
                <button class="btn btn-primary btn-editEvent btn-gray" type="submit">SAVE</button>
                <button class="btn btn-primary btn-editEvent btn-gray" type="button" onclick="cancelMessage('editVolunteer', 'volunteers')">CANCEL</button>
                <button class="btn btn-primary btn-editEvent btn-danger" type="button" onclick="deleteMessage('deleteVolunteer')">DELETE</button>
            </section>
            <section class="event">
                <p class="danger"><?php if(isset($error['email'])) { echo $error['email']; } ?></p>
                <label for="password">Email:</label>
                <input class="input" type="text" id="specialguest" name="email" value="<?php echo $volunteer->getEmail(); ?>" required>
                <label class="mb-19px">Password:</label>
                <input class="input" type="password" id="specialguest" name="password" placeholder="Password" required value="fakepass">
                <input type="hidden" name="action" value="update"/>
            </section>
            <section class="event">
                <label for="password">Which roles:</label>
                <label class="customCheck">Jazz
                    <input type="checkbox" <?php if($volunteer->getRole('Jazz')) { echo 'checked'; } ?> value="4" name="jazz">
                    <span class="checkmark"></span>
                </label>
                <label class="customCheck">Dance
                    <input type="checkbox" <?php if($volunteer->getRole('Dance')) { echo 'checked'; } ?> value="3" name="dance">
                    <span class="checkmark"></span>
                </label>
                <label class="customCheck">Historic
                    <input type="checkbox" <?php if($volunteer->getRole('Historic')) { echo 'checked'; } ?> value="2" name="historic">
                    <span class="checkmark"></span>
                </label>
                <label class="customCheck">Food
                    <input type="checkbox" <?php if($volunteer->getRole('Food')) { echo 'checked'; } ?> value="5" name="food">
                    <span class="checkmark"></span>
                </label>
            </section>
        </form>
        <form id="deleteVolunteer" method="POST" action="">
            <input type="hidden" name="action" value="delete"/>
        </form>
    </article>
</body>
</html>
