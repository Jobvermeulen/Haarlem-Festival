<!DOCTYPE html>
<html lang="en">
    <?php
        //Start session
        session_start();
        //Create volunteer model and controller
        $model = new volunteerModel();
        $controller = new volunteerController($model);

        //Check if user is signedin and is an Admin
        $controller->checkSignedIn();
        $controller->checkAdminRole();
        
        //Check if server request is post
        if($_SERVER["REQUEST_METHOD"] == "POST") {
            //Search volunteers in database
            $volunteers = $controller->searchVolunteer($_POST);
        }
        else {
            //Get all volunteers from datavase
            $volunteers = $controller->doGetVolunteers();
        }
    ?>
<head>
    <?php
    //Load the head
    $controller->loadHead();
    ?>  
    <title>Haarlem Festival - Volunteers</title>
</head>

<body>
    <?php
    // Load the menu
    $controller->loadMenu("volunteers");
    ?>

    <article class="container">
        <h1 class="mb-0">Volunteers</h1>
        <form id="volunteers" class="volunteers" method="POST" action="">
            <section class="row mb-5">
                <h2 class="m-10">Search Volunteer</h2>
                <a class="btn btn-gray right addbtn" href="/addVolunteer">Add Volunteer</a>
            </section>
            <section class="row">
                <section class="width33">
                    <p class="chooseP">Search by:</p>
                    <label class="custom-select">
                        <select id="choose" name="choose" onchange="selectVolunteerBy(event)">
                            <option value="username">Username</option>
                            <option value="roles">Assigned Role</option>
                        </select>
                    </label>

                    <section id="role" style="display: none;">
                        <p class="chooseP">Select Role:</p>
                        <label class="custom-select">
                            <select id="roleSelect" name="roleSelect">
                                <option value='4'>Jazz</option>
                                <option value='3'>Dance</option>
                                <option value='5'>Food</option>
                                <option value='2'>Historic</option>
                            </select>
                        </label>
                    </section>
                    <section id="username">
                        <p class="chooseP">Give username</p>
                        <input class="input" size="25" type="text" id="name" name="username" placeholder="Username" required autofocus>
                    </section>
                    <section>
                        <button class="btn btn-login btn-primary" type="submit">Search</button>
                    </section>
                </section>
                <section class="width66 malr">
                    <table class="hfTable">
                        <tr>
                            <th>UserID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Edit</th>
                        </tr>
                        <?php
                            //Check if there is a error
                            if(isset($volunteers['noUserError']))
                            {   //Echo error
                                echo '<tr>'.$volunteers['noUserError'].'</tr>';
                            }
                            else
                            {   //Echo all volunteers in table row
                                foreach($volunteers as $volunteer)
                                {
                                    echo '
                                    <tr>    
                                        <td>'.$volunteer->getVolunteerID().'</td>
                                        <td>'.$volunteer->getUsername().'</td>
                                        <td>'.$volunteer->getEmail().'</td>
                                        <td><a href="editVolunteer?volunteerID='.$volunteer->getVolunteerID().'">Edit<a></td>
                                    </tr>';
                                }
                            }
                        ?>
                    </table>
                </section>
            </section>
        </form>
    </article>
</body>
</html>
