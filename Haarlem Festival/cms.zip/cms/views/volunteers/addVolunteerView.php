<!DOCTYPE html>
<html lang="en">
    <?php
        //Start session
        session_start();
        //Create new volunteer model and controller
        $model = new volunteerModel();
        $controller = new volunteerController($model);

        //Check if is signedIN and an Admin
        $controller->checkSignedIn();
        $controller->checkAdminRole();
        //Check if server request is POST
        if($_SERVER["REQUEST_METHOD"] == "POST") {
            //Add volunteer to database
            $error = $controller->doAddVolunteer($_POST);
        }
    ?>
<head>
    <?php
    //Load the head
    $controller->loadHead();
    ?>  
    <title>Haarlem Festival - Edit Volunteer</title>
</head>


<body>
    <?php
    // Load the menu
    $controller->loadMenu("volunteers");
    ?>

    <article class="container">
        <h1 class="mb-0">Add Volunteer</h1>
        <form id="addVolunteer" class="editEvent" method="POST" action="">
            <p class="danger"><?php if(isset($error['basicError'])) { echo $error['basicError']; } ?></p>
            <section class="event">
                <p class="danger"><?php if(isset($error['username'])) { echo $error['username']; } ?></p>
                <label for="username">Username:</label>
                <input class="input" size="25" type="text" id="event" placeholder="Username" name="username" required autofocus value="<?php if(isset($_POST['username'])) { echo $_POST['username']; } ?>">
                <button class="btn btn-primary btn-editEvent btn-gray right" type="submit">SAVE</button>
                <button class="btn btn-primary btn-editEvent btn-gray right" type="button" onclick="cancelMessage('addVolunteer', 'volunteers')">CANCEL</button>
            </section>
            <section class="event">
                <p class="danger"><?php if(isset($error['email'])) { echo $error['email']; } ?></p>
                <label for="password">Email:</label>
                <input class="input" type="text" id="email" name="email" placeholder="Email" required value="<?php if(isset($_POST['email'])) { echo $_POST['email']; } ?>">
                <label class="mb-19px">Password:</label>
                <input class="input" type="password" id="specialguest" name="password" placeholder="Password" required>
            </section>
            <section class="event">
                <label for="password">Which roles:</label>
                <label class="customCheck">Jazz
                    <input type="checkbox" value="4" name="jazz" <?php if(isset($_POST['jazz'])) { echo 'checked'; } ?>>
                    <span class="checkmark"></span>
                </label>
                <label class="customCheck">Dance
                    <input type="checkbox" value="3" name="dance" <?php if(isset($_POST['dance'])) { echo 'checked'; } ?>>
                    <span class="checkmark"></span>
                </label>
                <label class="customCheck">Historic
                    <input type="checkbox" value="2" name="historic" <?php if(isset($_POST['historic'])) { echo 'checked'; } ?>>
                    <span class="checkmark"></span>
                </label>
                <label class="customCheck">Food
                    <input type="checkbox" value="5" name="food" <?php if(isset($_POST['food'])) { echo 'checked'; } ?>>
                    <span class="checkmark"></span>
                </label>
            </section>
        </form>
    </article>
</body>
</html>
