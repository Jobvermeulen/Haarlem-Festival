<?php
    //start session
    session_start();
    //Check if there is already a signedIN session running
    if(isset($_SESSION['signedIn']))
    {   //Move user to homepage
        header('Location: /home');
    }
    else {
        //Checks if there is a server request with method POST
        if($_SERVER["REQUEST_METHOD"] == "POST") {
            //Check username/password
            if(isset($_POST['username'],$_POST['password']) && !empty($_POST['username']) && !empty($_POST['password'])) {
                $username = $_POST['username'];
                $password = hash('sha256', $_POST['password']);

                //Declare new loginModel
                $model = new loginModel($username, $password);
                
                //Declare new loginController
                $controller = new loginController($model);
                //Gets errors from verifyLogin if credentials are not right
                $error = $controller->verifyLogin();
            }
            else {  //Error message if not everything is filled in
                $error['errorMessage'] = 'Not everything is filled in';
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    //Load head data
    $bController = new baseController();
    $bController->loadHead();
    ?>
    <title>CMS HaarlemFestival - Signin Page</title>
</head>
<body class="loginbg">
        <form class="login centered" method="POST" action="">
            <h1>CMS Signin Page</h1>
            <?php
                //Check if there is an errorMessage
                if(isset($error['errorMessage'])){
                    ?> <p class="danger text-center mt-15"> <?php
                    //Shows errorMessage
                    echo $error['errorMessage'];
                    ?> </p> <?php
                }
            ?>
            <section>
                <label for="username">Username</label>
                <input class="input" type="text" id="username" name="username" placeholder="Username" required autofocus>
            </section>
            <section>
                <label for="password">Password </label>
                <input class="input" type="password" id="password" name="password" placeholder="Password" required>
            </section>
            <section>
                <button class="btn btn-login btn-primary" type="submit">Signin</button>
            </section>
        </form>
</body>
</html>