<?php
    //Create sales model and controller
    $model = new salesModel();
    $controller = new salesController($model);
    //Get ticket availability csv
    $controller->doDownloadTicketAvailebility();
?>