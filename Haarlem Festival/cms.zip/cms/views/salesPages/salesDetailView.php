<!DOCTYPE html>
<html lang="en">
    <?php
        //Start session
        session_start();
        //Set customerID
        $customerID;
        //Check if customerID is set in url
        if(isset($_GET['customerID']))
        {   //Check if customerID is numeric
            if(is_numeric($_GET['customerID']))
            {   //Striptags and set in variable
                $customerID = strip_tags($_GET['customerID']);
            }
            else {  //Go to error page
                header('Location: /error404');
            }
        }
        else {  //Go to error page
            header('Location: /error404');
        }
        //Create new salesModel and controller
        $model = new salesModel();
        $controller = new salesController($model);

        //Check if user is signedin
        $controller->checkSignedIn();
        //Get ticket and customer data
        $tickets = $controller->doGetCustomerSales($customerID);
        $customer = $controller->doGetCustomer($customerID);
    ?>
<head>
    <?php
    //Load the head
    $controller->loadHead();
    ?>  
    <title>CMS Haarlem Festival - Customer Sales Detail</title>
</head>

<body>
    <?php
    // Load the menu
    $controller->loadMenu('');
    ?>

    <article class="container programme">
        <h1 class="mb-0">Customer Sales Detail</h1>
            <section class="row width100 mt-26 mpb">
                <section class="width33">
                    <h2 class="m-10">Customer</h2>
                </section>
                <section class="width66">
                    <h2 class="m-10">Tickets</h2>
                </section>
                <section class="width33 malr">
                    <table class="hfTable">
                        <tr>
                            <th>CustomerID</th>
                            <td><?php echo $customer->getCustomerID(); ?></td>
                        </tr>
                        <tr>
                            <th>Name</th>
                            <td><?php echo $customer->getCustomerName(); ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?php echo $customer->getCustomerEmail(); ?></td>
                        </tr>
                        <tr>
                            <th>Total Tickets</th>
                            <td><?php echo $customer->getTotalBought(); ?></td>
                        </tr>
                        <tr>
                            <th>Total Price</th>
                            <td>€ <?php echo number_format($customer->getTotalPrice(), 2); ?></td>
                        </tr>
                    </table>
                </section>
                <section class="width66 malr">
                    <table class="hfTable">
                        <tr>
                            <th>TicketID</th>
                            <th>Name</th>
                            <th>Event</th>
                            <th>Price Ticket</th>
                            <th>Quantity</th>
                            <th>Total Price</th>
                        </tr>
                        <?php
                        //Echo all tickets in table row
                        foreach($tickets as $ticket)
                        {
                            echo '
                            <tr>
                                <td>'. $ticket->getTicketID() .'</td>
                                <td>'. $ticket->getTicketName() .'</td>
                                <td>'. $ticket->getEventName() .'</td>
                                <td>€ '. number_format($ticket->getTicketPrice(), 2) .'</td>
                                <td>'. $ticket->getTicketQuantity() .'</td>
                                <td>€ '. number_format($ticket->getTicketQuantity()*$ticket->getTicketPrice(), 2) .'</td>
                            </tr>
                            ';
                        }
                        ?>
                    </table>
                </section>
            </section>
    </article>
</body>
</html>
