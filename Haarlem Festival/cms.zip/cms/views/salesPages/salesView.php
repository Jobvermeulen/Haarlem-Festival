<!DOCTYPE html>
<html lang="en">
    <?php
        //This page works one Ajax

        //Start session
        session_start();
        //Create $pageName variable
        $pageName = '';
        //Check if page is set in url
        if(isset($_GET['page']))
        {   //Strip tags and set in variable
            $pageName = strip_tags($_GET['page']);
            //Check if $pageName is not like one of this
            if($pageName != 'Jazz' && $pageName != 'Dance' && $pageName != 'Food' && $pageName != 'Historic' && $pageName != '')
            {   //Go to error page
                header('Location: /error404');
            }
        }
        //Create new salesModel and controller
        $model = new salesModel();
        $controller = new salesController($model);
        //Check if user is signed in
        $controller->checkSignedIn();
        
    ?>
<head>
    <?php
    //Load the head
    $controller->loadHead();
    ?>  
    <title>CMS Haarlem Festival - <?php echo $pageName?> Sales</title>
</head>

<body onload="getSalesTable('<?php echo $pageName; ?>')">
    <?php
    // Load the menu
    $controller->loadMenu($pageName);
    ?>

    <article class="container programme">
        <h1 class="mb-0">View Sales</h1>
            <section class="row width100 mt-26">
                <h2 class="m-10">Sales</h2>
                <label class="custom-select right">
                    <select name="location" onchange="getSalesTable(event)">
                        <option <?php if($pageName == '') { echo 'selected'; } ?> value=" ">All</option>
                        <option <?php if($pageName == 'Jazz') { echo 'selected'; } ?> value="Jazz">Jazz</option>
                        <option <?php if($pageName == 'Dance') { echo 'selected'; } ?> value="Dance">Dance</option>
                        <option <?php if($pageName == 'Food') { echo 'selected'; } ?> value="Food">Food</option>
                        <option <?php if($pageName == 'Historic') { echo 'selected'; } ?> value="Historic">Historic</option>
                    </select>
                </label>
            </section>
            <section class="width100 mpb" id="salesTable">
            </section>
    </article>
</body>
</html>
