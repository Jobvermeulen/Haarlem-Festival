<?php
    //Create sales model and controller
    $model = new salesModel();
    $controller = new salesController($model);
    //Get sales perday CSV 
    $controller->doGetSalesPerDay();
?>