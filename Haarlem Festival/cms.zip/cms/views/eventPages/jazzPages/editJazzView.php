<!DOCTYPE html>
<html lang="en">
    <?php
        //Start session
        session_start();
        //Check if ticketid is set and is numeric
        if(isset($_GET['ticketID']) && is_numeric($_GET['ticketID']))
        {   //Strip tags from ticketID and set in variable
            $ticketID = strip_tags($_GET['ticketID']);
            //Set pagename and eventID
            $pageName = 'Jazz';
            $eventID = '2';

            //Create new jazz/location model and controller
            $model = new jazzModel();
            $controller = new jazzController($model);
            $locationModel = new locationModel();
            $locationController = new locationController($locationModel);

            //Check if user is signedin and is an Admin/jazz
            $controller->checkSignedIn();
            $controller->checkRole($pageName);
            //Get jazz event from database
            $event = $controller->doGetJazzEvent($ticketID);
            //Check if server request is POST
            if($_SERVER["REQUEST_METHOD"] == "POST") {
                //Check if action is set and not empty
                if(isset($_POST['action']) && !empty($_POST['action']))
                {   //Check if action is update or delete
                    if($_POST['action'] == 'update')
                    {   //Edit jazz event in database
                        $error = $controller->doEditJazzEvent($_POST, $eventID, $ticketID);
                    }
                    elseif($_POST['action'] == 'delete')
                    {   //Delete jazz event from database
                        $controller->doDeleteEvent($ticketID, $pageName);
                    }
                }
            }  
            //Get locations, starttimes and duration
            $locations = $locationController->doGetAllLocations($pageName);
            $startTimes = $controller->getTimeArray('09:00:00', '23:30:00', '30 min');
            $durationTimes = $controller->getTimeArray('00:30:00', '03:30:00', '30 min');
        }
        else { //Go back to programme page
            header('Location: /programme?page='.$pageName);
        }
    ?>
<head>
    <?php
    //Load head data
    $controller->loadHead();
    ?>
    <title>CMS HaarlemFestival - Edit <?php echo $pageName; ?> Event</title>
</head>
<body>
    <?php //Get menu
    $controller->loadMenu($pageName);
    ?>
    <article class="container">
        <h1 class="mb-0">Edit <?php echo $pageName; ?> Event</h1>
        <form id="<?php echo $pageName; ?>Event" class="editEvent" method="POST" action="">
            <input type="hidden" name="action" value="update"/>
            <p class="danger"><?php if(isset($error['basicError'])) { echo $error['basicError']; } ?></p>
            <section class="event">
                <label for="username">Event name:</label>
                <input class="input" size="25" type="text" id="event" name="event" placeholder="Event name" required autofocus value="<?php echo $event->getEventName(); ?>">
                <button class="btn btn-primary btn-editEvent btn-danger right" type="button" onclick="deleteMessage('deleteEvent')">DELETE</button>
                <button class="btn btn-primary btn-editEvent btn-gray right" type="button" onclick="cancelMessage('<?php echo $pageName; ?>Event', 'programme?page=<?php echo $pageName; ?>')">CANCEL</button>
                <button class="btn btn-primary btn-editEvent btn-gray right" type="submit">SAVE</button>
            </section>
            <section class="event">
                <label>Artists:</label>
                <input class="input" type="text" id="artist" name="artist" placeholder="Artist" value="<?php echo $event->getArtists(); ?>">
                <label class="mb-19px">Location:</label>
                <label class="custom-select">
                    <select name="location" onchange="jazzHall(event)">
                        <?php
                        //Echo all locations
                        foreach($locations as $location)
                        {
                            if($event->getLocationID() == $location->getLocationID())
                            {
                                echo '<option selected value="'.$location->getLocationID().'">'. $location->getLocationName() .' | '. $location->getStreetname() .'</option>';
                            }
                            else {
                                echo '<option value="'.$location->getLocationID().'">'. $location->getLocationName() .' | '. $location->getStreetname() .'</option>';
                            }
                        }
                        ?>
                        <option <?php if($event->getLocationID() == '43') { echo 'selected'; } ?> value="43">No Location (For all access)</option>
                    </select>
                </label>
            </section>
            <section class="event">
                <label>Category:</label>
                <input class="input" type="text" id="cat" name="cat" placeholder="<?php echo $pageName; ?>" disabled required>
                <label class="mb-19px">Hall:</label>
                <label class="custom-select">
                    <select name="hall" id="hallSelect">
                        <option <?php if($event->getHall() == 'Main Hall') { echo 'selected'; } ?> value="Main Hall">Main</option>
                        <option <?php if($event->getHall() == 'Second Hall') { echo 'selected'; } ?> value="Second Hall">Second</option>
                        <option <?php if($event->getHall() == 'Third Hall') { echo 'selected'; } ?> value="Third Hall">Third</option>
                        <option <?php if($event->getHall() == '') { echo 'selected'; } ?> value="">-</option>
                    </select>
                </label>
            </section>

            <section class="event select">
                <label for="price">Ticket price:</label>
                <input class="input" type="number" oninput="checkNumber(event)" step="any" min="0" id="price" name="price" placeholder="Price (12.50)" required value="<?php echo number_format($event->getPrice(), 2); ?>">
                <label class="mb-19px">Start time:</label>
                <label class="custom-select">
                    <select name="startTime">
                        <?php
                            //Echo all starttimes
                            foreach($startTimes as $time)
                            {
                                if($event->getTime() == $time->format('H:i:s'))
                                {
                                    echo '<option selected value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                }
                                else {
                                    echo '<option value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                }
                            }
                        ?>
                        <option <?php if($event->getTime() == '') { echo 'selected'; } ?> value="-">No Time (For all access)</option>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label for="quantity">Quantity:</label>
                <input class="input" type="number" oninput="checkNumber(event)" id="quantity" name="quantity" placeholder="Quantity (120)" min="0" required value="<?php echo $event->getQuantity(); ?>">
                <label class="mb-19px">Duration:</label>
                <label class="custom-select">
                    <select name="duration">
                        <?php
                            //Echo all durationTimes
                            foreach($durationTimes as $time)
                            {
                                if($event->getDuration() == $time->format('H:i:s'))
                                {
                                    echo '<option selected value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                }
                                else {
                                    echo '<option value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                }                            
                            }  
                        ?>
                        <option <?php if($event->getDuration() == '') { echo 'selected'; } ?> value="-">No Duration (For all access)</option>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label class="mb-19px">Day:</label>
                <label class="custom-select">
                    <select name="date">
                        <option <?php if($event->getDate() == '2019-07-26') { echo 'selected'; } ?> value='2019-07-26'>26-07-2019</option>
                        <option <?php if($event->getDate() == '2019-07-27') { echo 'selected'; } ?> value='2019-07-27'>27-07-2019</option>
                        <option <?php if($event->getDate() == '2019-07-28') { echo 'selected'; } ?> value='2019-07-28'>28-07-2019</option>
                        <option <?php if($event->getDate() == '2019-07-29') { echo 'selected'; } ?> value='2019-07-29'>29-07-2019</option>
                        <option <?php if($event->getDate() == '') { echo 'selected'; } ?> value='-'>No date (for all access)</option>
                    </select>
                </label>
            </section>
        </form>
        <form method="POST" id="deleteEvent" name="deleteEvent" action="">
            <input type="hidden" name="action" value="delete"/>
        </form>
    </article>
</body>
</html>