<!DOCTYPE html>
<html lang="en">
    <?php
        //start session
        session_start();
        //set pagename and eventid
        $pageName = 'Food';
        $eventID = '4';
        
        //create food/location model and controller
        $model = new foodModel();
        $controller = new foodController($model);
        $locationModel = new locationModel();
        $locationController = new locationController($locationModel);

        //Check if user is signedin and is an Admin/food
        $controller->checkSignedIn();
        $controller->checkRole($pageName);

        //Check if server request method is post
        if($_SERVER["REQUEST_METHOD"] == "POST") {
            //Add food event in database
            $error = $controller->doAddFoodEvent($_POST, $_FILES['image'], $eventID);
        }
        //Get locations, starttimes and duration
        $locations = $locationController->doGetAllLocations($pageName);
        $startTimes = $controller->getTimeArray('12:30:00', '24:00:00', '30 min');
        $durationTimes = $controller->getTimeArray('00:30:00', '06:30:00', '30 min');
    ?>
<head>
    <?php
    //Load head data
    $controller->loadHead();
    ?>
    <title>CMS HaarlemFestival - Add <?php echo $pageName; ?> Event</title>
</head>
<body>
    <?php
    $controller->loadMenu($pageName);
    ?>
    <article class="container">
        <h1 class="mb-0">Add <?php echo $pageName; ?> Event</h1>
        <form id="<?php echo $pageName; ?>Event" class="editEvent" method="POST" action="" enctype="multipart/form-data">
            <p class="danger"><?php if(isset($error['basicError'])) { echo $error['basicError']; } ?></p>
            <section class="event">
                <label for="username">Restaurant:</label>
                <input class="input" size="25" type="text" id="event" name="event" placeholder="Restaurant Name" required autofocus value="<?php if(isset($_POST['event'])) { echo $_POST['event']; } ?>">
                <button class="btn btn-primary btn-editEvent btn-gray right" type="button" onclick="cancelMessage('<?php echo $pageName; ?>Event', 'programme?page=<?php echo $pageName; ?>')">CANCEL</button>
                <button class="btn btn-primary btn-editEvent btn-gray right" type="submit">SAVE</button>
            </section>
            <section class="event select">
                <label for="food">Type food:</label>
                <input class="input" type="text" id="food" name="food" placeholder="Type (Dutch, fish)" required value="<?php if(isset($_POST['food'])) { echo $_POST['food']; } ?>">
                <label class="mb-19px">Stars:</label>
                <label class="custom-select">
                    <select name="stars">
                        <option <?php if(isset($_POST['stars'])) { if($_POST['stars'] == '1') { echo 'selected'; }} ?> value="1">1</option>
                        <option <?php if(isset($_POST['stars'])) { if($_POST['stars'] == '2') { echo 'selected'; }} ?> value="2">2</option>
                        <option <?php if(isset($_POST['stars'])) { if($_POST['stars'] == '3') { echo 'selected'; }} ?> value="3">3</option>
                        <option <?php if(isset($_POST['stars'])) { if($_POST['stars'] == '4') { echo 'selected'; }} ?> value="4">4</option>
                        <option <?php if(isset($_POST['stars'])) { if($_POST['stars'] == '5') { echo 'selected'; }} ?> value="5">5</option>
                    </select>
                </label>
            </section>
            <section class="event">
                <label>Category:</label>
                <input class="input" type="text" id="cat" name="cat" placeholder="<?php echo $pageName; ?>" disabled required>
                <label class="mb-19px">Start time:</label>
                <label class="custom-select">
                    <select name="startTime">
                        <?php
                            //Echo all start times
                            foreach($startTimes as $time)
                            {
                                if(isset($_POST['startTime'])) 
                                { 
                                    if($_POST['startTime'] == $time->format('H:i:s'))
                                    {
                                        echo '<option selected value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                    }
                                    else
                                    {
                                        echo '<option value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                    }
                                }
                                else
                                {
                                    echo '<option value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                }
                            }
                        ?>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label for="price">Ticket price:</label>
                <input class="input" type="number" oninput="checkNumber(event)" step="any" min="0" id="price" name="price" placeholder="Price (12.50)" required value="<?php if(isset($_POST['price'])) { echo number_format($_POST['price'], 2); } ?>">
                <label class="mb-19px">Duration:</label>
                <label class="custom-select">
                    <select name="duration">
                        <?php
                            //Echo all durations
                            foreach($durationTimes as $time)
                            {
                                if(isset($_POST['duration'])) 
                                { 
                                    if($_POST['duration'] == $time->format('H:i:s'))
                                    {
                                        echo '<option selected value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                    }
                                    else
                                    {
                                        echo '<option value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                    }
                                }
                                else
                                {
                                    echo '<option value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                }
                            }
                        ?>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label for="price">Reducedprice:</label>
                <input class="input" type="number" oninput="checkNumber(event)" step="any" id="reducedprice" name="reducedprice" placeholder="ReducedPrice (12.50)" required value="<?php if(isset($_POST['reducedprice'])) { echo number_format($_POST['reducedprice'], 2); } ?>">
                <label class="mb-19px">Sessions:</label>
                <label class="custom-select">
                    <select name="sessions">
                        <option <?php if(isset($_POST['sessions'])) { if($_POST['sessions'] == '1') { echo 'selected'; }} ?> value="1">1</option>
                        <option <?php if(isset($_POST['sessions'])) { if($_POST['sessions'] == '2') { echo 'selected'; }} ?> value="2">2</option>
                        <option <?php if(isset($_POST['sessions'])) { if($_POST['sessions'] == '3') { echo 'selected'; }} ?> value="3">3</option>
                        <option <?php if(isset($_POST['sessions'])) { if($_POST['sessions'] == '4') { echo 'selected'; }} ?> value="4">4</option>
                        <option <?php if(isset($_POST['sessions'])) { if($_POST['sessions'] == '5') { echo 'selected'; }} ?> value="5">5</option>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label for="quantity">Quantity:</label>
                <input class="input" type="number" oninput="checkNumber(event)" id="quantity" name="quantity" placeholder="Quantity (120)" min="0" required value="<?php if(isset($_POST['quantity'])) { echo $_POST['quantity']; } ?>">
                <label class="mb-19px">Day:</label>
                <label class="custom-select">
                    <select name="date">
                        <option <?php if(isset($_POST['date'])) { if($_POST['date'] == '2019-07-26') { echo 'selected'; }} ?> value='2019-07-26'>26-07-2019</option>
                        <option <?php if(isset($_POST['date'])) { if($_POST['date'] == '2019-07-27') { echo 'selected'; }} ?> value='2019-07-27'>27-07-2019</option>
                        <option <?php if(isset($_POST['date'])) { if($_POST['date'] == '2019-07-28') { echo 'selected'; }} ?> value='2019-07-28'>28-07-2019</option>
                        <option <?php if(isset($_POST['date'])) { if($_POST['date'] == '2019-07-29') { echo 'selected'; }} ?> value='2019-07-29'>29-07-2019</option>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label class="mb-19px">Location:</label>
                <label class="custom-select">
                    <select name="location" onchange="newLocation(event)">
                        <?php
                        //Echo all durations
                        foreach($locations as $location)
                        {
                            if(isset($_POST['location'])) 
                            { 
                                if($_POST['location'] == $location->getLocationID())
                                {
                                    echo '<option selected value="'.$location->getLocationID().'">'. $location->getLocationName() .' | '. $location->getStreetname() .'</option>';
                                }
                                else
                                {
                                echo '<option value="'.$location->getLocationID().'">'. $location->getLocationName() .' | '. $location->getStreetname() .'</option>';
                                }
                            }
                            else
                            {
                                echo '<option value="'.$location->getLocationID().'">'. $location->getLocationName() .' | '. $location->getStreetname() .'</option>';
                            }
                        }
                        ?>
                        <option value="new">New Location (fill in below)</option>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label class="mb-19px"> Image (max 4mb):</label>
                <input type="file" class="custom-file-input" name="image" id="image" accept="image/*" required onclick="fileSize(event);"/>
                <img id="showImage" width="248px" height="140px" style="vertical-align: middle;">
            </section>
            <section id="location1" class="event" style="display:none;">
                <h3>New location</h3>
                <label for="locationName">Name:</label>
                <input class="input" type="text" id="locationName" name="locationName" placeholder="Name" disabled required value="<?php if(isset($_POST['locationName'])) { echo $_POST['locationName']; } ?>">
                <label for="street">Street:</label>
                <input class="input" type="text" id="street" name="street" placeholder="Street + number" disabled required value="<?php if(isset($_POST['street'])) { echo $_POST['street']; } ?>">
            </section>
            <section id="location2" class="event" style="display:none">
                <label for="zipcode">Zipcode:</label>
                <input class="input" type="text" id="zipcode" name="zipcode" placeholder="Zipcode (1234AB)" disabled required value="<?php if(isset($_POST['zipcode'])) { echo $_POST['zipcode']; } ?>">
                <label for="city">City:</label>
                <input class="input" type="text" id="city" name="city" placeholder="City" disabled required value="<?php if(isset($_POST['city'])) { echo $_POST['city']; } ?>">
            </section>
            <section id="location3" class="event" style="display:none">
                <label for="url">url:</label>
                <input class="input" type="text" id="url" name="url" placeholder="Website URL" disabled required value="<?php if(isset($_POST['url'])) { echo $_POST['url']; } ?>">
            </section>
        </form>
    </article>
    <script>
        
    </script>
</body>
</html>