<!DOCTYPE html>
<html lang="en">
    <?php
        //start session
        session_start();
        //check if ticketid is set and is numeric
        if(isset($_GET['ticketID']) && is_numeric($_GET['ticketID']))
        {   //Striptags from tickeid and set in variable
            $ticketID = strip_tags($_GET['ticketID']);
            //Set page name and eventid
            $pageName = 'Food';
            $eventID = '4';
            
            //Create new food/location model and controller
            $model = new foodModel();
            $controller = new foodController($model);
            $locationModel = new locationModel();
            $locationController = new locationController($locationModel);

            //Check if user is signedin and is an Admin/food
            $controller->checkSignedIn();
            $controller->checkRole($pageName);
            //Get food event from database
            $event = $controller->doGetFoodEvent($ticketID);

            //Check if server request method is post
            if($_SERVER["REQUEST_METHOD"] == "POST") {
                //Check if action is set and not empty
                if(isset($_POST['action']) && !empty($_POST['action']))
                {   //Check if action is update of delete
                    if($_POST['action'] == 'update')
                    {   //Update food event in database
                        $error = $controller->doEditFoodEvent($_POST, $_FILES['image'], $eventID, $ticketID, $event->getImageID(), $event->getEventName(), $event->getImage());
                    }
                    elseif($_POST['action'] == 'delete')
                    {   //Delete food event from database
                        $controller->doDeleteEvent($ticketID, $pageName);
                    }
                }
            }
            //Get all locations, starttimes and durations
            $locations = $locationController->doGetAllLocations($pageName);
            $startTimes = $controller->getTimeArray('16:30:00', '24:00:00', '30 min');
            $durationTimes = $controller->getTimeArray('00:30:00', '02:30:00', '30 min');
        }
        else { //Go back to programme page
            header('Location: programme?page='.$pageName);
        }
    ?>
<head>
    <?php
    //Load head data
    $controller->loadHead();
    ?>
    <title>CMS HaarlemFestival - Edit <?php echo $pageName; ?> Event</title>
</head>
<body>
    <?php
    $controller->loadMenu($pageName);
    ?>
    <article class="container">
        <h1 class="mb-0">Edit <?php echo $pageName; ?> Event</h1>
        <form id="<?php echo $pageName; ?>Event" class="editEvent" method="POST" action="" enctype="multipart/form-data">
            <input type="hidden" name="action" value="update"/>
            <p class="danger"><?php if(isset($error['basicError'])) { echo $error['basicError']; } ?></p>
            <section class="event">
                <label for="username">Restaurant:</label>
                <input class="input" size="25" type="text" id="event" name="event" placeholder="Restaurant Name" required autofocus value="<?php echo $event->getEventName(); ?>">
                <button class="btn btn-primary btn-editEvent btn-danger right" type="button" onclick="deleteMessage('deleteEvent')">DELETE</button>
                <button class="btn btn-primary btn-editEvent btn-gray right" type="button" onclick="cancelMessage('<?php echo $pageName; ?>Event', 'programme?page=<?php echo $pageName; ?>')">CANCEL</button>
                <button class="btn btn-primary btn-editEvent btn-gray right" type="submit">SAVE</button>
            </section>
            <section class="event select">
                <label for="food">Type food:</label>
                <input class="input" type="text" id="food" name="food" placeholder="Type (Dutch, fish)" required value="<?php echo $event->getType(); ?>">
                <label class="mb-19px">Stars:</label>
                <label class="custom-select">
                    <select name="stars">
                        <option <?php if($event->getStars() == '1') { echo 'selected'; } ?> value="1">1</option>
                        <option <?php if($event->getStars() == '2') { echo 'selected'; } ?> value="2">2</option>
                        <option <?php if($event->getStars() == '3') { echo 'selected'; } ?> value="3">3</option>
                        <option <?php if($event->getStars() == '4') { echo 'selected'; } ?> value="4">4</option>
                        <option <?php if($event->getStars() == '5') { echo 'selected'; } ?> value="5">5</option>
                    </select>
                </label>
            </section>
            <section class="event">
                <label>Category:</label>
                <input class="input" type="text" id="cat" name="cat" placeholder="<?php echo $pageName; ?>" disabled required>
                <label class="mb-19px">Start time:</label>
                <label class="custom-select">
                    <select name="startTime">
                        <?php
                            //Echo all starttimes
                            foreach($startTimes as $time)
                            {
                                if($event->getTime() == $time->format('H:i:s'))
                                {
                                    echo '<option selected value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                }
                                else {
                                    echo '<option value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                }
                            }
                        ?>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label for="price">Ticket price:</label>
                <input class="input" type="number" oninput="checkNumber(event)" step="any" min="0" id="price" name="price" placeholder="Price (12.50)" required value="<?php echo number_format($event->getPrice(), 2); ?>">
                <label class="mb-19px">Duration:</label>
                <label class="custom-select">
                    <select name="duration">
                        <?php
                            //Echo all durations
                            foreach($durationTimes as $time)
                            {
                                if($event->getDuration() == $time->format('H:i:s'))
                                {
                                    echo '<option selected value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                }
                                else {
                                    echo '<option value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                }                            
                            }  
                        ?>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label for="price">Reducedprice:</label>
                <input class="input" type="number" oninput="checkNumber(event)" step="any" id="reducedprice" name="reducedprice" placeholder="ReducedPrice (12.50)" required value="<?php echo number_format($event->getReducedPrice(),2); ?>">
                <label class="mb-19px">Day:</label>
                <label class="custom-select">
                    <select name="date">
                        <option <?php if($event->getDate() == '2019-07-26') { echo 'selected'; } ?> value='2019-07-26'>26-07-2019</option>
                        <option <?php if($event->getDate() == '2019-07-27') { echo 'selected'; } ?> value='2019-07-27'>27-07-2019</option>
                        <option <?php if($event->getDate() == '2019-07-28') { echo 'selected'; } ?> value='2019-07-28'>28-07-2019</option>
                        <option <?php if($event->getDate() == '2019-07-29') { echo 'selected'; } ?> value='2019-07-29'>29-07-2019</option>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label for="quantity">Quantity:</label>
                <input class="input" type="number" oninput="checkNumber(event)" id="quantity" name="quantity" placeholder="Quantity (120)" min="0" required value="<?php echo $event->getQuantity(); ?>">
            </section>
            <section class="event select">
                <label class="mb-19px">Location:</label>
                <label class="custom-select">
                    <select name="location">
                        <?php
                        //Echo all locations
                        foreach($locations as $location)
                        {
                            if($event->getLocationID() == $location->getLocationID())
                            {
                                echo '<option selected value="'.$location->getLocationID().'">'. $location->getLocationName() .' | '. $location->getStreetname() .'</option>';
                            }
                            else {
                                echo '<option value="'.$location->getLocationID().'">'. $location->getLocationName() .' | '. $location->getStreetname() .'</option>';
                            }
                        }
                        ?>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label class="mb-19px"> Image (max 4mb):</label>
                <input type="file" class="custom-file-input" name="image" id="image" accept="image/*" onclick="fileSize(event);"/>
                <img id="showImage" width="248px" height="140px" style="vertical-align: middle;" src="https://haarlem-festival.nl/<?php echo $event->getImage(); ?>">
            </section>
        </form>
        <form method="POST" id="deleteEvent" name="deleteEvent" action="">
            <input type="hidden" name="action" value="delete"/>
        </form>
    </article>
    <script>
        
    </script>
</body>
</html>