<!DOCTYPE html>
<html lang="en">
    <?php
        //Start session
        session_start();
        //Set pagename and eventID
        $pageName = 'Historic';
        $eventID = '1';
        
        //Create historic/location model and controller
        $model = new historicModel();
        $controller = new historicController($model);
        $locationModel = new locationModel();
        $locationController = new locationController($locationModel);

        //Check if user is signedin and is an Admin
        $controller->checkSignedIn();
        $controller->checkRole($pageName);
        //Create error array
        $error = array();
        //Check if server request is post 
        if($_SERVER["REQUEST_METHOD"] == "POST") {
            //Add historic event to database
            $error = $controller->doAddHistoricEvent($_POST, $eventID);
        }
        //Get all lcoations, starttimes and durations
        $locations = $locationController->doGetAllLocations($pageName);
        $startTimes = $controller->getTimeArray('10:00:00', '20:00:00', '30 min');
        $durationTimes = $controller->getTimeArray('00:30:00', '03:30:00', '30 min');
    ?>
<head>
    <?php
    //Load head data
    $controller->loadHead();
    ?>
    <title>CMS HaarlemFestival - Add <?php echo $pageName; ?> Event</title>
</head>
<body>
    <?php
    $controller->loadMenu($pageName);
    ?>
    <article class="container">
        <h1 class="mb-0">Add <?php echo $pageName; ?> Event</h1>
        <form id="<?php echo $pageName; ?>Event" class="editEvent" method="POST" action="">
            <p class="danger"><?php if(isset($error['basicError'])) { echo $error['basicError']; } ?></p>
            <section class="event">
                <label for="username">Tour name:</label>
                <input class="input" size="25" type="text" id="event" name="event" placeholder="Tour name" required autofocus value="<?php if(isset($_POST['event'])) { echo $_POST['event']; } ?>">
                <button class="btn btn-primary btn-editEvent btn-gray right" type="submit">SAVE</button>
                <button class="btn btn-primary btn-editEvent btn-gray right" type="button" onclick="cancelMessage('<?php echo $pageName; ?>Event', 'programme?page=<?php echo $pageName; ?>')">CANCEL</button>
            </section>
            <section class="event">
                <label>Language:</label>
                <input class="input" type="text" id="language" name="language" placeholder="Language" required value="<?php if(isset($_POST['language'])) { echo $_POST['language']; } ?>">
                <label class="mb-19px">Location:</label>
                <label class="custom-select">
                    <select name="location" required>
                        <?php
                        //Echo all locations
                        foreach($locations as $location)
                        {
                            if(isset($_POST['location'])) 
                            { 
                                if($_POST['location'] == $location->getLocationID())
                                {
                                    echo '<option selected value="'.$location->getLocationID().'">'. $location->getLocationName() .' | '. $location->getStreetname() .'</option>';
                                }
                                else
                                {
                                    echo '<option value="'.$location->getLocationID().'">'. $location->getLocationName() .' | '. $location->getStreetname() .'</option>';
                                }
                            }
                            else
                            {
                                echo '<option value="'.$location->getLocationID().'">'. $location->getLocationName() .' | '. $location->getStreetname() .'</option>';
                            }
                        }
                        ?>
                    </select>
                </label>
            </section>
            <section class="event">
                <label>Category:</label>
                <input class="input" type="text" id="cat" name="cat" placeholder="<?php echo $pageName; ?>" disabled>
                <label class="mb-19px">Start time:</label>
                <label class="custom-select">
                    <select name="startTime" required>
                        <?php
                            //Echo all starttimes
                            foreach($startTimes as $time)
                            {
                                if(isset($_POST['startTime'])) 
                                { 
                                    if($_POST['startTime'] == $time->format('H:i:s'))
                                    {
                                        echo '<option selected value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                    }
                                    else
                                    {
                                        echo '<option value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                    }
                                }
                                else
                                {
                                    echo '<option value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                }
                            }
                        ?>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label for="price">Ticket price:</label>
                <input class="input" type="number" oninput="checkNumber(event)" step="any" min="0" id="price" name="price" placeholder="Price (12.50)" required value="<?php if(isset($_POST['price'])) { echo number_format($_POST['price'], 2); } ?>">
                <label class="mb-19px">Duration:</label>
                <label class="custom-select">
                    <select name="duration" required>
                        <?php
                            //Echo all durations
                            foreach($durationTimes as $time)
                            {
                                if(isset($_POST['duration'])) 
                                { 
                                    if($_POST['duration'] == $time->format('H:i:s'))
                                    {
                                        echo '<option selected value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                    }
                                    else
                                    {
                                        echo '<option value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                    }
                                }
                                else
                                {
                                    echo '<option value="'.$time->format('H:i:s').'">'.$time->format('H:i:s').'</option>';
                                }
                            }
                        ?>
                    </select>
                </label>
            </section>
            <section class="event select">
                <label for="quantity">Quantity:</label>
                <input class="input" type="number" oninput="checkNumber(event)" id="quantity" name="quantity" placeholder="Quantity (120)" min="0" required value="<?php if(isset($_POST['quantity'])) { echo $_POST['quantity']; } ?>">
                <label class="mb-19px">Day:</label>
                <label class="custom-select">
                    <select name="date" required>
                        <option <?php if(isset($_POST['date'])) { if($_POST['date'] == '2019-07-26') { echo 'selected'; }} ?> value='2019-07-26'>26-07-2019</option>
                        <option <?php if(isset($_POST['date'])) { if($_POST['date'] == '2019-07-27') { echo 'selected'; }} ?> value='2019-07-27'>27-07-2019</option>
                        <option <?php if(isset($_POST['date'])) { if($_POST['date'] == '2019-07-28') { echo 'selected'; }} ?> value='2019-07-28'>28-07-2019</option>
                        <option <?php if(isset($_POST['date'])) { if($_POST['date'] == '2019-07-29') { echo 'selected'; }} ?> value='2019-07-29'>29-07-2019</option>
                    </select>
                </label>
            </section>
            <section class="event">
                <label for="guide">Tour guide:</label>
                <input class="input" type="text" id="guide" name="guide" placeholder="Tour Guide" required value="<?php if(isset($_POST['guide'])) { echo $_POST['guide']; } ?>">
            </section>
        </form>
    </article>
</body>
</html>