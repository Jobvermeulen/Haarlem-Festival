<!DOCTYPE html>
<html lang="en">
    <?php
        //Start session
        session_start();
        //Create pagename
        $pageName;
        //Check if pagename is set in url
        if(isset($_GET['page']))
        {   //Striptags from page and set in variable
            $pageName = strip_tags($_GET['page']);
            //Check if pagename is not like some of this in the if
            if($pageName != 'Jazz' && $pageName != 'Dance' && $pageName != 'Food' && $pageName != 'Historic' )
            {   //Go to errorpage
                header('Location: /error404');
            }
        }
        else {
            //Go to error page
            header('Location: /error404');
        }
        //Create new eventmodel and controller
        $model = new eventModel();
        $controller = new eventController($model);

        //Check if user is signedin and is an Admin/specific volunteer
        $controller->checkSignedIn();
        $controller->checkRole($pageName);
        //Get programme from database
        $events = $controller->doGetProgramme($pageName);
    ?>
<head>
    <?php
    //Load the head
    $controller->loadHead();
    ?>  
    <title>CMS Haarlem Festival - <?php echo $pageName?> Programme</title>
</head>

<body>
    <?php
    // Load the menu
    $controller->loadMenu($pageName);
    ?>

    <article class="container programme">
        <h1 class="mb-0">Manage <?php echo $pageName?> Programme</h1>
            <section class="row width100 mt-26">
                <h2 class="m-10"><?php echo $pageName?> Programme</h2>
                <a class="btn btn-gray right addbtn" href="/add<?php echo $pageName; ?>">Add Event</a>
            </section>
            <section class="width100 mpb">
                <?php
                //Set date to 1970
                $date = '01-01-1970';
                //Echo all events
                foreach($events as $event)
                {   //Check if date is same as set $date
                    if($date == $event->getDate())
                    {   //Echo table row
                        echo '
                        <tr>    
                            <td>'.$event->getEventName().'</td>
                            <td>'.$event->getTime().'</td>
                            <td>'.date("l d-m-Y", strtotime($event->getDate())).'</td>
                            <td>'.$event->getLocationName().'</td>
                            <td>€ '. number_format($event->getPrice(), 2) .'</td>
                            <td>'.$event->getQuantity().'</td>
                            <td><a href="edit'. $pageName .'?ticketID='.$event->getTicketID().'">Edit<a></td>
                        </tr>';
                    }
                    else {
                        //Set new date in $date
                        $date = $event->getDate();
                        //Show date is in format: Monday 11-12-1999
                        $showDate = date("l d-m-Y", strtotime($event->getDate()));
                        if($date == '')
                        {   //If date is empty echo Multi all access
                            echo '</table>
                            <h2>Multi All-access pass</h2>';
                            $showDate = 'All days';
                        }
                        else { //Echo showdate
                            echo '
                            </table>
                            <h2>'. $showDate .'</h2>';
                        } //Echo table head and first row
                        echo '
                        <table class="hfTable">
                            <tr>
                                <th>Event</th>
                                <th>StartTime</th>
                                <th>Date</th>
                                <th>Location</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Edit</th>
                            </tr>
                            <tr>    
                                <td>'.$event->getEventName().'</td>
                                <td>'.$event->getTime().'</td>
                                <td>'.$showDate.'</td>
                                <td>'.$event->getLocationName().'</td>
                                <td>€ '.number_format($event->getPrice(), 2) .'</td>
                                <td>'.$event->getQuantity().'</td>
                                <td><a href="edit'. $pageName .'?ticketID='.$event->getTicketID().'">Edit<a></td>
                            </tr>';
                    }
                }
                ?>
                </table>
            </section>
    </article>
</body>
</html>
