<?php
//This file contains data for the salesView
//Data will requested with ajax and returned a Table

//Check for server request get
if($_SERVER["REQUEST_METHOD"] == "GET")
{   //Create sales model and controller
    $model = new salesModel();
    $controller = new salesController($model);
    //Set pagename and then check if page is set in URL
    $pageName = '';
    if(isset($_GET['page']))
    {   //Strip tags and then set page in pageName
        $pageName = strip_tags($_GET['page']);
    }

    //Collect the sales data
    $sales = $controller->doGetAllSales($pageName);

    //Echo table head info
    echo 
    '
    <table class="hfTable">
        <tr>
            <th>CustometID</th>
            <th>Customer</th>
            <th>Email</th>
            <th>Total Tickets</th>
            <th>Total Price</th>
            <th>View Details</th>
        </tr>
    ';
    //Foreach row in sales make new table row
    foreach($sales as $customer)
    {
        echo '
            <tr>    
                <td>'.$customer->getCustomerID().'</td>
                <td>'.$customer->getCustomerName().'</td>
                <td>'.$customer->getCustomerEmail().'</td>
                <td>'.$customer->getTotalBought().'</td>
                <td>€ '.number_format($customer->getTotalPrice(), 2) .'</td>
                <td><a href="salesDetail?customerID='.$customer->getCustomerID().'">View<a></td>
            </tr>';
    }
    echo '</table>';
}
else {
    //Error if something went wrong
    echo 'Something went wrong try again later!';
}