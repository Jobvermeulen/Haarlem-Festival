<?php
//This file contains data for the charts on the dashboard pages
//Data will requested with ajax and returned in json
//Set header to JSON
header('Content-Type: application/json');
//Create array
$data = array();

//Check if there is server request with method get
if($_SERVER["REQUEST_METHOD"] == "GET")
{
    //Create new salesModel and controller
    $model = new salesModel();
    $controller = new salesController($model);

    //Check if chart name is dailysales of soldAvailable
    if($_GET['chart'] == 'dailySales')
    {
        //Get data from doGetDailySales and set in $data
        $getData = $controller->doGetDailySales($_GET['page']);
        $data = $getData;
    }
    elseif($_GET['chart'] == 'soldAvailable')
    {
        //Get the ticket and customer data
        $getData = $controller->doGetTicketAndCustomerData($_GET['page']);
        //Check if sold and avail qunaitiy is set and is numeric
        if(isset($getData['soldQuantity'], $getData['availableQuantity']) && is_numeric($getData['soldQuantity']) && is_numeric($getData['availableQuantity']))
        {
            //Set soldQuantity in sold and availableQuantity in available
            $data['sold'] = $getData['soldQuantity'];
            $data['available'] = $getData['availableQuantity'];
        }
    }
}
//Echo the data in json
echo json_encode($data);