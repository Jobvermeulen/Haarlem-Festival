<?php
//This php file contains all routes that are working for this website

//Index routes
router::set('index', function() {
    router::$found = 1;
    baseController::createView('index');
});

router::set('index.php', function() {
    router::$found = 1;
    baseController::createView('index');
});

//Homepages route
router::set('home', function() {
    router::$found = 1;
    baseController::createView('homePages/index');
});

//Programme route
router::set('programme', function() {
    router::$found = 1;
    baseController::createView('eventPages/programme');
});

//Content route
router::set('content', function() {
    router::$found = 1;
    baseController::createView('contentPages/content');
});

router::set('editText', function() {
    router::$found = 1;
    baseController::createView('contentPages/editTextContent');
});

router::set('editImage', function() {
    router::$found = 1;
    baseController::createView('contentPages/editImageContent');
});

//Sales route
router::set('sales', function() {
    router::$found = 1;
    baseController::createView('salesPages/sales');
});

router::set('salesDetail', function() {
    router::$found = 1;
    baseController::createView('salesPages/salesDetail');
});

//Download CSV
router::set('csvDownload', function() {
    router::$found = 1;
    baseController::createView('salesPages/downloadCSV');
});
router::set('csvDownloadPerDay', function() {
    router::$found = 1;
    baseController::createView('salesPages/downloadCSVPerDay');
});

router::set('test', function() {
    router::$found = 1;
    baseController::createView('test');
});

//Jazz
router::set('addJazz', function() {
    router::$found = 1;
    baseController::createView('eventPages/jazzPages/addJazz');
});

router::set('editJazz', function() {
    router::$found = 1;
    baseController::createView('eventPages/jazzPages/editJazz');
});

//Dance
router::set('addDance', function() {
    router::$found = 1;
    baseController::createView('eventPages/dancePages/addDance');
});

router::set('editDance', function() {
    router::$found = 1;
    baseController::createView('eventPages/dancePages/editDance');
});

//Food
router::set('addFood', function() {
    router::$found = 1;
    baseController::createView('eventPages/foodPages/addFood');
});

router::set('editFood', function() {
    router::$found = 1;
    baseController::createView('eventPages/foodPages/editFood');
});

//Historic
router::set('addHistoric', function() {
    router::$found = 1;
    baseController::createView('eventPages/historicPages/addHistoric');
});

router::set('editHistoric', function() {
    router::$found = 1;
    baseController::createView('eventPages/historicPages/editHistoric');
});

// Volunteer routes
router::set('volunteers', function() {
    router::$found = 1;
    baseController::createView('volunteers/index');
});

router::set('editVolunteer', function() {
    router::$found = 1;
    baseController::createView('volunteers/editVolunteer');
});

router::set('addVolunteer', function() {
    router::$found = 1;
    baseController::createView('volunteers/addVolunteer');
});

//Logout route
router::set('logout', function() {
    router::$found = 1;
    logoutController::doLogout();   
});

//Ajax routes
router::set('ajaxDashboard', function() {
    router::$found = 1;
    baseController::createView('ajax/dashboard');
});

router::set('ajaxSalesTable', function() {
    router::$found = 1;
    baseController::createView('ajax/salesTable');
});

//Error 403 route
router::set('error403', function() {
    router::$found = 1;
    baseController::createView('errorPages/error403');
});

//Error 404 route
if (router::$found == 0) {
    router::set($_GET['url'], function() {
        baseController::createView('errorPages/error404');
    });
}