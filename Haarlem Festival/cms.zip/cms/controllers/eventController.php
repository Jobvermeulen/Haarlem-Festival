<?php
    class eventController extends baseController 
    {
        protected $model;

        //Construct that sets the model
        public function __construct(eventModel $model) 
        {
            $this->model = $model;
        }
        
        //Get programme
        public function doGetProgramme(string $pageName)
        {
            try {
                //Get result from database
                if($result = $this->model->getProgramme($pageName))
                { 
                    //Create array
                    $events = array();
                    //Foreach row in result loop
                    foreach($result as $row)
                    {   //create eventModel and set event
                        $event = new eventModel();
                        $event->setEvent($row['eventID'], $row['ticketID'], $row['eventName'], $row['time'], $row['date'], $row['locationName'], $row['price'], $row['quantity']);
                        //Add event to array
                        $events[] = $event;
                    }
                    //Return array
                    return $events;
                }
                else 
                {
                    //Exception if it did not get the programme
                    throw new Exception('Getting programme failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage;
            }
        }

        //Function to delete event
        public function doDeleteEvent(int $ticketID, string $pageName)
        {
            try {
                //Try to remove event
                if($this->model->deleteEvent($ticketID)) {
                    //Go to programme page if ticket is deleted
                    header('Location: /programme?page='. $pageName);
                }
                else {
                    //Exception if removing event did not work
                    throw new Exception('deleteEvent failed. Try again later!');
                }
            }
            catch (Exception $e){
                //Show error message
                echo $e->getMessage();
            }
        }

        //Function to create time array
        public function getTimeArray(string $givenBegin, string $givenEnd, string $givenInterval)
        {
            //Set begin and end date
            $begin = new DateTime($givenBegin);
            $end = new DateTime($givenEnd);
            //Set interval
            $interval = DateInterval::createFromDateString($givenInterval);
            //Add times to array
            $times = new DatePeriod($begin, $interval, $end);
            //Return array
            return $times;
        }
    }