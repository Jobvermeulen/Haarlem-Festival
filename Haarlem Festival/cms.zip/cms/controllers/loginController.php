<?php
    class loginController extends baseController 
    {
        //Declare model
        private $model;

        //Construct that sets the model
        public function __construct(loginModel $model) 
        {
            $this->model = $model;
        }

        //Function that verifyLogin
        function verifyLogin() 
        {
            try 
            {
                //Get result from credentialcheck
                if(!$result = $this->model->checkCredentials())
                {
                    //Throw exception when something went wrong when function
                    throw new Exception('Loginsystem failed. Try again later!');
                }
                else {
                    //Check if result exists
                    if (isset($result)) {
                        //Check if result has more than 0 rows
                        if($result->num_rows > 0) {
                            //Check if user only has 1 group
                            if($result->num_rows == 1) {
                                //Get data from result and set data in session and go to homepage
                                $user = mysqli_fetch_assoc($result);
                                $_SESSION['signedIn'] = true;
                                $_SESSION['userID'] = $user['userID'];
                                $_SESSION['roles'][0] = $user['rolename'];
                                header('Location: home');
                            }
                            else
                            {
                                //Declare some variables
                                $round = 0;
                                $userID = '';
                                //Foreach that adds every role to the session
                                foreach($result as $role)
                                {   
                                    //Add role to session
                                    $_SESSION['roles'][] = $role['rolename'];
                                    //Check if $rounds is bigger than 0
                                    if($round > 0) {
                                        //Check if userID from previous round is the same as this round
                                        if(!($userID == $role['userID']))
                                        {
                                            //If userID is different give errorMessage
                                            $error['errorMessage'] = 'Your username or password are incorrect';
                                        }
                                        else {
                                            //Add 1 to round
                                            $round++;
                                        }
                                    }
                                    else {
                                        //Set userID for first time and add 1 to round
                                        $userID = $role['userID'];
                                        $round++;
                                    }
                                }
                                //Add data to session and go to homepage
                                $_SESSION['signedIn'] = true;
                                $_SESSION['userID'] = $userID;
                                header('Location: /home');
                            }
                        }
                        else {
                            //Add errormessage if username or password are incorrect
                            $error['errorMessage'] = 'Your username or password are incorrect';
                        }
                    }
                    else {
                        //Throw exception if result does not exists
                        throw new Exception('Loginsystem failed. Try again later!');
                    }
                    //Return errors
                    return $error;
                }
            }
            catch (Exception $e) 
            {
                //Show exception messages
                echo $e->getMessage();
            }
        }
    }