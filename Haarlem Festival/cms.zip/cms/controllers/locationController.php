<?php
    class locationController extends baseController
    {
        private $model;

        //Construct that sets the model
        public function __construct(locationModel $model)
        {
            $this->model = $model;
        }

        //Get location
        public function doGetAllLocations(string $pageName)
        {
            try {
                //Get result from 
                if($result = $this->model->getAllLocations($pageName))
                { 
                    //Create array
                    $locations = array();
                    //Foreach row in result loop
                    foreach($result as $row)
                    {
                        //create eventModel and set location
                        $location = new locationModel();
                        $location->setLocation($row['locationID'], $row['name'], $row['street'], $row['zipcode'], $row['city']);
                        //Add location to array
                        $locations[] = $location;
                    }
                    //Return locations
                    return $locations;
                }
                else 
                {
                    //Exception if it did not get the location
                    throw new Exception('Getting all locations failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage;
            }
        }
    }