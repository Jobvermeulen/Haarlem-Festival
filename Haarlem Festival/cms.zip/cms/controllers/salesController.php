<?php
    class salesController extends baseController 
    {
        private $model;

        public function __construct(salesModel $model)
        {
            $this->model = $model;
        }

        //Function to get customer and ticket data
        public function doGetTicketAndCustomerData($pageName)
        {
            try
            {
                //Try to get sold ticket data
                if($result = $this->model->getTicketAndCustomerData($pageName))
                {   //Check if result is 1 rows
                    if($result->num_rows == 1)
                    {
                        //Fetch data
                        $data = $result->fetch_assoc();
                        //Check if some things are set
                        if(isset($data['soldQuantity'], $data['availableQuantity'], $data['revenue']))
                        {
                            //Create total quantity
                            $data['totalQuantity'] = $data['soldQuantity'] + $data['availableQuantity'];
                        }
                        else {
                            //set everything to 0
                            $data['totalQuantity'] = $data['availableQuantity'];
                            $data['soldQuantity'] = 0;
                            $data['revenue'] = 0;
                        }
                    }
                    //Return data
                    return $data;
                }
                else {
                    //Throw exception if didn't get data
                    throw new Exception('get SoldTicket Data failed. Try again later!');
                }
            }
            catch (Exception $e) {
                //Show thrown error
                echo $e->getMessagge();
            }
        }

        //Fucntion to get weekly customer and ticket data
        public function doGetWeeklyTAndCData($pageName)
        {
            try
            {
                //Create start and end data of the week
                $startDate = date('Y-m-d', strtotime('monday this week'));
                $endDate = date('Y-m-d', strtotime('+6 days'));
                //Try to get sold ticket data
                if($result = $this->model->getWeeklyTAndCData($pageName, $startDate, $endDate))
                {   //Check if result is 1 row
                    if($result->num_rows == 1)
                    {   //Fetch the row
                        $data = $result->fetch_assoc();
                    }
                    //Return data
                    return $data;
                }
                else {
                    //Throw exception if didn't get data
                    throw new Exception('doGetWeeklyTAndCData failed. Try again later!');
                }
            }
            catch (Exception $e) {
                //Show throw error
                echo $e->getMessage();
            }
        }

        //Function to get dailysales
        public function doGetDailySales($pageName)
        {
            try
            {
                //Set Start and endDAte
                $startDate = date('Y-m-d',strtotime(date('Y-m-d') . "-9 days"));
                $endDate = date('Y-m-d',strtotime(date('Y-m-d') . "+1 days"));
                //Try to get sold ticket data
                if($result = $this->model->getDailySales($pageName,$startDate,$endDate))
                {
                    //Create array and fetch 1 row
                    $data = array();
                    $row = $result->fetch_assoc();
                    $date = $startDate;
                    //For loop that will run 9 times
                    for($i = 0; $i <= 9; $i++)
                    {
                        //Create second array and add the date to it
                        $dailySales = array();
                        $dailySales['date'] = date('d-m', strtotime($date));
                        //If that checks if date from db is the same as current date
                        if($row['date'] == $date)
                        {   //Add soldQuantity to array and fetch new row
                            $dailySales['sold'] = $row['soldQuantity'];
                            $row = $result->fetch_assoc();
                        }
                        else {
                            //Set sold to 0
                            $dailySales['sold'] = 0;
                        }
                        //Up date by 1 day and add array to data array
                        $date = date('Y-m-d',strtotime($date . "+1 days"));
                        $data[] = $dailySales;
                    }
                    //Return data
                    return $data;
                }
                else {
                    //Throw exception if didn't get data
                    throw new Exception('getDailySales Data failed. Try again later!');
                }
            }
            catch (Exception $e) {
                //Show thrown error
                echo $e->getMessage();
            }
        }
        
        //Function to get all sales
        public function doGetAllSales(string $pageName)
        {
            try {
                //Get result from database
                if($result = $this->model->getAllSales($pageName))
                { 
                    //Create array
                    $sales = array();
                    //Foreach row as result loop
                    foreach($result as $row)
                    {
                        //Create salesModel and set customer
                        $customer = new salesModel();
                        $customer->setCustomer($row['customerID'], $row['quantity'], $row['price'], $row['name'], $row['email']);
                        //Ass customer to array
                        $sales[] = $customer;
                    }
                    //Return array
                    return $sales;
                }
                else 
                {
                    //Exception if it did not get the volunteers
                    throw new Exception('Getting all sales failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }

        //Function to get customer sales
        public function doGetCustomerSales(int $customerID)
        {
            try {
                //Get result from database
                if($result = $this->model->getCustomerSales($customerID))
                { 
                    //Create array
                    $sales = array();
                    foreach($result as $row)
                    {
                        //Create salesModel and set ticket
                        $ticket = new salesModel();
                        $ticket->setBoughtTicket($row['name'], $row['eventname'], $row['price'], $row['quantity'], $row['ticketID']);
                        //Add ticket to array
                        $sales[] = $ticket;
                    }
                    //Return array
                    return $sales;
                }
                else 
                {
                    //Exception if it did not get the volunteers
                    throw new Exception('Getting customer sales failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }

        //Do get customer
        public function doGetCustomer(int $customerID)
        {
            try {
                //Get result from database
                if($result = $this->model->getCustomer($customerID))
                { 
                    //Fetch row
                    $row = $result->fetch_assoc();
                    //Check if row is not null
                    if($row != null)
                    {   //Create salesModel and set customer
                        $customer = new salesModel();
                        $customer->setCustomer($row['customerID'], $row['quantity'], $row['price'], $row['name'], $row['email']);
                        //return customer
                        return $customer;
                    }
                    else {  //Go to errorpage if row is null
                        header('Location: /error404');
                    }
                }
                else 
                {
                    //Exception if it did not get the volunteers
                    throw new Exception('Getting all sales failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }

        //Function for generating csv file with ticket availebility
        public function doDownloadTicketAvailebility()
        {
            try {
                //Get result from database
                if($result = $this->model->downloadTicketAvailebility())
                { 
                    // write the first line to a file, make sure you have modified the rights of the directory to make the directory writable!!! (CHMOD)
                    $file = "HaarlemFestivalTicketAvailebility.csv";
                    $path = "/home/thomaur292/domains/haarlem-festival.nl/public_html/cms/downloads/HaarlemFestivalTicketAvailebility.csv";

                    $csv = fopen("/home/thomaur292/domains/haarlem-festival.nl/public_html/cms/downloads/HaarlemFestivalTicketAvailebility.csv", "w") or die("Unable to create file!");
                    
                    $line = "Event name; Ticket name; Event Time; Event Date; Ticket Price; Ticket Availebility\n";
                    fwrite($csv, $line);
                    
                    while($row = $result->fetch_assoc())
                    {
                        $line = '';  
                        
                        $line .= $row["eventname"].";";
                        $line .= $row["name"].";";
                        $line .= $row["time"].";";
                        $line .= $row["date"].";";
                        $line .= number_format($row["price"], 2).";";
                        $line .= $row["quantity"].";";
                        
                        $line .= "\n";
                        fwrite($csv, $line);	
                    }	
                    
                    fclose($csv);

                    //set headers to download file rather than displayed
                    header("Cache-Control: public");
                    header("Content-Description: File Transfer");
                    header("Content-Disposition: attachment; filename=$file");
                    header("Content-Type: application/csv");
                    header("Content-Transfer-Encoding: binary");

                    // read the file from disk
                    readfile($path);
                    
                }
                else 
                {
                    //Exception if it did not get the volunteers
                    throw new Exception('Generating csv failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }

        //Function for generating csv file with sales per day
        public function doGetSalesPerDay()
        {
            try {
                //Get result from database
                if($result = $this->model->getSalesPerDay())
                { 
                    // write the first line to a file, make sure you have modified the rights of the directory to make the directory writable!!! (CHMOD)
                    $file = "HaarlemFestival_Sales_Per_Day.csv";
                    $path = "/home/thomaur292/domains/haarlem-festival.nl/public_html/cms/downloads/HaarlemFestival_Sales_Per_Day.csv";

                    $csv = fopen("/home/thomaur292/domains/haarlem-festival.nl/public_html/cms/downloads/HaarlemFestival_Sales_Per_Day.csv", "w") or die("Unable to create file!");
                    
                    $line = "Event name; Ticket name; Event date; Date Ticket sold; Sold Ticket price; Sold Ticket quantity; Total Price\n";
                    fwrite($csv, $line);
                    
                    while($row = $result->fetch_assoc())
                    {
                        $line = '';  
                        
                        $line .= $row["eventname"].";";
                        $line .= $row["name"].";";
                        $line .= $row["date"].";";
                        $line .= $row["timestamp"].";";
                        $line .= number_format($row["price"], 2).";";
                        $line .= $row["quantity"].";";
                        $line .= number_format($row["price"]*$row['quantity'], 2).";";
                        
                        $line .= "\n";
                        fwrite($csv, $line);	
                    }	
                    
                    fclose($csv);

                    //set headers to download file rather than displayed
                    header("Cache-Control: public");
                    header("Content-Description: File Transfer");
                    header("Content-Disposition: attachment; filename=$file");
                    header("Content-Type: application/csv; charset=UTF-8");
                    header("Content-Transfer-Encoding: binary");

                    // read the file from disk
                    readfile($path);
                    
                }
                else 
                {
                    //Exception if it did not get the volunteers
                    throw new Exception('Generating csv failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }
    }