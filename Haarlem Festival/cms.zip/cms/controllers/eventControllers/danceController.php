<?php
    class danceController extends eventController
    {
        public function __construct(danceModel $model)
        {   //Set model in parent
            parent::__construct($model);
        }

        //Function to add danceevent
        public function doAddDanceEvent(array $formData, int $eventID)
        {
            try
            {   //Check if everything that is required is set
                if(isset($formData['event'], $formData['artist'], $formData['price'], $formData['quantity'], $formData['location'], $formData['startTime'], $formData['duration'], $formData['date']))
                {   //Check if somethings are not empty
                    if(!empty($formData['event']) && !empty($formData['artist']) && !empty($formData['price']) && !empty($formData['quantity']) && !empty($formData['location']) && !empty($formData['startTime']) && !empty($formData['duration']) && !empty($formData['date']))
                    {   //Check if something are numbers
                        if(is_numeric($formData['price']) && is_numeric($formData['quantity']))
                        {   //Add danceevent to database
                            if($this->model->addDanceEvent($formData, $eventID))
                            {   //Go back to programme 
                                header('Location: programme?page=Dance');
                            }
                            else {  //Throw exception if not added to daatabase
                                throw new Exception('Adding dance event failed');
                            }
                        }
                        else {  //Show error if not number
                            $error['basicError'] = 'You did not fill in a number (event, price or quantity)';
                        }
                    }
                    else {  //Show error if something is empty
                        $error['basicError'] = 'You left (artist, event, price or quantity) empty';
                    }
                }
                else {  //Show error if not everything is filled in
                    $error['basicError'] = 'Not everything is filled in';
                }
                //return error
                return $error;
            }
            catch (Exception $e) {
                //Show thrown exception
                echo $e->getMessage();
            }
        }

        //Function to edit danceevent
        public function doEditDanceEvent(array $formData, int $eventID, int $ticketID)
        {   //Because of the all access ticket artist can't be checked
            try
            {   //Check if everything that is required is set
                if(isset($formData['event'], $formData['price'], $formData['quantity'], $formData['location'], $formData['startTime'], $formData['duration'], $formData['date']))
                {   //Check if somethings are not empty
                    if(!empty($formData['event']) && !empty($formData['price']) && !empty($formData['location']) && !empty($formData['startTime']) && !empty($formData['duration']) && !empty($formData['date']))
                    {   //Check if something are numbers
                        if(is_numeric($formData['price']) && is_numeric($formData['quantity']))
                        {   //For all access set null values
                            if($formData['startTime'] == '-') {
                                $formData['startTime'] = null;
                            }
                            if ($formData['duration'] == '-') {
                                $formData['duration'] = null;
                            }
                            if ($formData['date'] == '-') {
                                $formData['date'] = null;
                            }
                            //edit danceevent in database
                            if($this->model->editDanceEvent($formData, $eventID, $ticketID))
                            {   //Go back to programme 
                                header('Location: programme?page=Dance');
                            }
                            else { //Throw exception if not edited to daatabase
                                throw new Exception('Editing dance event failed');
                            }
                        }
                        else { //Show error if not number
                            $error['basicError'] = 'You did not fill in a number (event, price or quantity)';
                        }
                    }
                    else { //Show error if something is empty
                        $error['basicError'] = 'You left (artist, event, price or quantity) empty';
                    }
                }
                else { //Show error if not everything is filled in
                    $error['basicError'] = 'Not everything is filled in';
                }
                //return error
                return $error;
            }
            catch (Exception $e) {
                //show thrown exception
                echo $e->getMessage();
            }
        }

        //Function to get danceevent
        public function doGetDanceEvent(int $ticketID)
        {
            try {
                //Get result from database
                if($result = $this->model->getDanceEvent($ticketID))
                {
                    //Fetch row and check if row is not null
                    $row = mysqli_fetch_assoc($result);
                    if($row == null)
                    {
                        //Go back to programme
                        header('Location: /programme?page=Dance');
                    }
                    else
                    {
                        //Make danceModel and set danceevent
                        $event = new danceModel();
                        $event->setDanceEvent($row['name'], $row['time'], $row['date'], $row['locationID'], $row['price'], $row['quantity'], $row['notice'], $row['duration'], $row['artists']);
                        //Return danceevent
                        return $event;
                    }
                }
                else 
                {
                    //Exception if it did not get the danceEvent
                    throw new Exception('Getting dance event failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage;
            }
        }
    }