<?php
    class foodController extends eventController
    {
        //Set parent model
        public function __construct(foodModel $model)
        {
            parent::__construct($model);
        } 

        //Function to edit food event
        public function doEditFoodEvent(array $formData, array $picture, int $eventID, int $ticketID, int $imageID, string $eventName, string $path)
        {
            try
            {   //Create content model and controller
                $contentModel = new contentModel();
                $contentController = new contentController($contentModel);

                $imagePath;
                $error = array();
                $error['basicError'] = '';
                //Check if some variables are set
                if(isset($formData['event'], $formData['stars'], $formData['price'], $formData['quantity'], $formData['startTime'], $formData['duration'], $formData['date'], $formData['reducedprice'], $formData['location'], $formData['food'], $picture))
                {   //Check if some variables are not empty
                    if(!empty($formData['event']) &&  !empty($formData['stars']) && !empty($formData['food']) && !empty($formData['reducedprice']) && !empty($formData['price']) && !empty($formData['quantity']) && !empty($formData['location']) && !empty($formData['startTime']) && !empty($formData['duration']) && !empty($formData['date']) && !empty($picture))
                    {   //Check if some variables are a number
                        if(is_numeric($formData['price']) && is_numeric($formData['quantity']) && is_numeric($formData['reducedprice']) && is_numeric($formData['stars']))
                        {   //Check if picture has error for non picture uploaded
                            if($picture['error'] == 4)
                            {
                                $imagePath = $path;
                            }
                            else 
                            {
                                //Upload picture
                                $error = $contentController->uploadFile($picture, 'images/uploads/');
                                $imagePath = 'images/uploads/' . $picture['name'];
                                //Check if image is uploaded
                                if($error != 'completed')
                                { 
                                    return $error;
                                }
                            }
                            //Add image to db
                            if($contentModel->updateImageContent($imagePath, $imageID, $formData['event']))    
                            {   //Edit all events sessions (name, location)
                                if($this->model->editAllFoodEventSessions($formData, $eventID, $eventName))
                                {   //Edit specific food event (price, quantity)
                                    if($this->model->editFoodEvent($formData, $eventID, $ticketID))
                                    {
                                        //Than go to programme of food
                                        header('Location: programme?page=Food');
                                    }
                                }
                                else {  //Throw exception if adding failed
                                    throw new Exception('Editing food sessions failed');
                                }
                            }
                            else {  //Throw exception if adding failed
                                throw new Exception('Could not edit image path to db');
                            }
                        }
                        else { //Set error and return error if not everything is a number
                            $error['basicError'] = 'You did not fill in a number (event, price, quantity, sessions, reducedPrice or stars)';
                        }
                    }
                    else { //Set error and return error if not everything is filled in
                        $error['basicError'] = 'You left something empty';
                    }
                }
                else {  //Set error if not everything is filled in
                    $error['basicError'] = 'Not everything is filled in';
                }
                return $error;
            }
            catch (Exception $e) {
                echo $e->getMessage();
            }
        }

        public function doAddFoodEvent(array $formData, array $picture, int $eventID)
        {
            try
            {
                //Create content model and controller
                $contentModel = new contentModel();
                $contentController = new contentController($contentModel);
                $locationModel = new locationModel();
                $locationController = new locationController($locationModel);

                $webPlacementID;
                $locationID;
                //Check if some variables are set
                if(isset($formData['event'], $formData['stars'], $formData['sessions'], $formData['price'], $formData['quantity'], $formData['startTime'], $formData['duration'], $formData['date'], $formData['reducedprice'], $formData['location'], $formData['food'], $picture, $picture['name']))
                {   //Check if some variables are not empty
                    if(!empty($formData['event']) &&  !empty($formData['stars']) && !empty($formData['food']) && !empty($formData['sessions']) && !empty($formData['reducedprice']) && !empty($formData['price']) && !empty($formData['quantity']) && !empty($formData['location']) && !empty($formData['startTime']) && !empty($formData['duration']) && !empty($formData['date']) && !empty($picture))
                    {   //Check if some variables are a number
                        if(is_numeric($formData['price']) && is_numeric($formData['quantity']) && is_numeric($formData['sessions']) && is_numeric($formData['reducedprice']) && is_numeric($formData['stars']))
                        {   
                            if(isset($_POST['zipcode']))
                            {
                                if(!preg_match("/^\W*[1-9]{1}[0-9]{3}\W*[a-zA-Z]{2}\W*$/", $_POST['zipcode']))
                                {
                                    $error['basicError'] = 'Zipcode is not in the right format! (1234AB)';
                                    return $error;
                                }
                            }
                            //Insert webPlacement and get latest webPlacementID
                            if($webPlacementID = $contentModel->createWebPlacement('image_'.$formData['event']))
                            {   //Check if location value is new
                                if($formData['location'] == 'new')
                                {   //Create new location and get locationID
                                    if(!($locationID = $locationModel->addLocation($formData['locationName'], $formData['street'], $formData['city'], $formData['zipcode'], $formData['url'], $eventID)))
                                    {
                                        //Throw exception if adding location failed
                                        throw new Exception('Adding location failed');
                                    }
                                }
                                else {
                                    //Set location in $locationID
                                    $locationID = $formData['location'];
                                }
                                //Upload image
                                $error = $contentController->uploadFile($picture, 'images/uploads/');
                                //Check if image is uploaded
                                if($error == 'completed')
                                {   //Add image to database
                                    $path = 'images/uploads/' . $picture['name'];
                                    if($contentModel->addImageContent($path, $eventID, $webPlacementID, $formData['event']))  
                                    {
                                        //Set startTime
                                        $startTime = $formData['startTime'];
                                        //For loop that loops the count of times of variable session
                                        for($i = 1; $i <= $formData['sessions']; $i++)
                                        {   //If i is not equal to one
                                            if($i != 1) {
                                                //Add duration to startTime and update startTime
                                                $timeToSeconds = strtotime($formData['duration'])-strtotime("00:00:00");
                                                $startTime = date("H:i:s",strtotime($startTime)+$timeToSeconds);
                                            }
                                            //Add food event to database
                                            if($this->model->addFoodEvent($formData, $eventID, $startTime, $locationID, $webPlacementID))
                                            {
                                                //Check if $i equals sessions
                                                if($i == $formData['sessions'])
                                                {   //Than go to programme of food
                                                    header('Location: programme?page=Food');
                                                }
                                            }
                                            else {  //Throw exception if adding failed
                                                throw new Exception('Adding food event failed');
                                            }
                                        }
                                    }
                                }
                                else {  //Return $error;
                                    return $error;
                                }
                            }
                            else {  //Throw excpetion if adding webplacement failed
                                throw new Exception('Adding webPlacement failed');
                            }
                        }
                        else { //Set error and return error if not everything is a number
                            $error['basicError'] = 'You did not fill in a number (event, price, quantity, sessions, reducedPrice or stars)';
                        }
                    }
                    else { //Set error and return error if not everything is filled in
                        $error['basicError'] = 'You left something empty';
                    }
                }
                else { 
                    $error['basicError'] = 'Not everything is filled in';
                }
                return $error;
            }
            catch (Exception $e) {
                echo $e->getMessage();
            }
        }

        //Function to get food event
        public function doGetFoodEvent(int $ticketID)
        {
            try {
                //Get result from 
                if($result = $this->model->getFoodEvent($ticketID))
                {   //Fetch row
                    $row = mysqli_fetch_assoc($result);
                    //Check if row is null
                    if($row == null)
                    {   //Go to programme of food
                        header('Location: /programme?page=Food');
                    }
                    else
                    {
                        //Create foodmodel and set foodevent
                        $event = new foodModel();
                        $event->setFoodEvent($row['name'], $row['time'], $row['date'], $row['locationID'], $row['price'], $row['quantity'], $row['duration'], $row['typeFood'], $row['starsFood'], $row['reducedPrice'], $row['image'], $row['webPlacementID'], $row['imageID']);
                        //Return event
                        return $event;
                    }
                }
                else 
                {
                    //Exception if it did not get the danceEvent
                    throw new Exception('Getting food event failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }
    }