<?php 
    class jazzController extends eventController
    {
        public function __construct(jazzModel $model){
            parent::__construct($model);
        }

        //Function to add jazzevent
        public function doAddJazzEvent(array $formData, int $eventID)
        {
            try
            {   //Check if everything that is required is set
                if(isset($formData['event'], $formData['artist'], $formData['price'], $formData['quantity'], $formData['location'], $formData['startTime'], $formData['duration'], $formData['date']))
                {   //Check if somethings are not empty
                    if(!empty($formData['event']) && !empty($formData['artist']) && !empty($formData['quantity']) && !empty($formData['location']) && !empty($formData['startTime']) && !empty($formData['duration']) && !empty($formData['date']))
                    {   //Check if something are numbers
                        if(is_numeric($formData['price']) && is_numeric($formData['quantity']))
                        {   //Check if hall is not set
                            if(!isset($formData['hall']))
                            {   //Set hall empty
                                $hall = '';
                            }
                            else {
                                //Set hall as data from form
                                $hall = $formData['hall'];
                            }
                            //Add jazzevent to database
                            if($this->model->addJazzEvent($formData, $hall, $eventID))
                            {   //Go back to programme 
                                header('Location: programme?page=Jazz');
                            }
                            else {  //Throw exception if not added to daatabase
                                throw new Exception('Adding jazz event failed');
                            }
                        }
                        else {  //Show error if not number
                            $error['basicError'] = 'You did not fill in a number (event,price or quantity)';
                        }
                    }
                    else {  //Show error if something is empty
                        $error['basicError'] = 'You left (artist, event, price or quantity) empty';
                    }
                }
                else {  //Show error if not everything is filled in
                    $error['basicError'] = 'Not everything is filled in';
                }
                //Return error
                return $error;
            }
            catch (Exception $e) {
                //Show thrown exception
                echo $e->getMessage();
            }
        }

        //Function to edit jazzevent
        public function doEditJazzEvent(array $formData, int $eventID, int $ticketID)
        {   //Because of all access we can't check everything with updating like artists
            try
            {   //Check if everything that is required is set
                if(isset($formData['event'], $formData['price'], $formData['location'], $formData['startTime'], $formData['duration'], $formData['date'], $formData['quantity']))
                {   //Check if somethings are not empty
                    if(!empty($formData['event']) && !empty($formData['location']) && !empty($formData['startTime']) && !empty($formData['duration']) && !empty($formData['date']))
                    {   //Check if something are numbers
                        if(is_numeric($formData['price']) && is_numeric($formData['quantity']))
                        {   //Set some values to null because of All Access
                            if($formData['startTime'] == '-') {
                                $formData['startTime'] = null;
                            }
                            if ($formData['duration'] == '-') {
                                $formData['duration'] = null;
                            }
                            if ($formData['date'] == '-') {
                                $formData['date'] = null;
                            }
                            //Check if hall is not set
                            if(!isset($formData['hall']))
                            {   //Set hall empty
                                $hall = '';
                            }
                            else {
                                //Set hall as data from form
                                $hall = $formData['hall'];
                            }
                            //edit jazzevent in database
                            if($this->model->editJazzEvent($formData, $hall, $eventID, $ticketID))
                            {   //Go back to programme
                                header('Location: programme?page=Jazz');
                            }
                            else { //Throw exception if not edited to daatabase
                                throw new Exception('Editing jazz event failed');
                            }
                        }
                        else { //Show error if not number
                            $error['basicError'] = 'You did not fill in a number (event,price or quantity)';
                        }
                    }
                    else { //Show error if something is empty
                        $error['basicError'] = 'You left (artist, event, price or quantity) empty';
                    }
                }
                else { //Show error if not everything is filled in
                    $error['basicError'] = 'Not everything is filled in';
                }
                //return error
                return $error;
            }
            catch (Exception $e) {
                //show thrown exception
                echo $e->getMessage();
            }
        }

        //Function to get jazzevent
        public function doGetJazzEvent(int $ticketID)
        {
            try {
                //Get result from database
                if($result = $this->model->getJazzEvent($ticketID))
                {
                    //Fetch row and check if row is not null
                    $row = mysqli_fetch_assoc($result);
                    if($row == null)
                    {
                        //Go back to programme
                        header('Location: /programme?page=Jazz');
                    }
                    else
                    {
                        //Make jazzModel and set jazzevent
                        $event = new jazzModel();
                        $event->setJazzEvent($row['name'], $row['time'], $row['date'], $row['locationID'], $row['price'], $row['quantity'], $row['hallJazz'], $row['duration'], $row['artists']);
                        //Return jazzevent
                        return $event;
                    }
                }
                else 
                {
                    //Exception if it did not get the jazzEvent
                    throw new Exception('Getting jazz event failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage;
            }
        }
    }