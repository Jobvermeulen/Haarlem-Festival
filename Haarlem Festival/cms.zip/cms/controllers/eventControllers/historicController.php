<?php
    class historicController extends eventController
    {
        public function __construct(historicModel $model)
        {   //Set model in parent
            parent::__construct($model);
        }

        //Function to add historicevent
        public function doAddHistoricEvent(array $formData, int $eventID)
        {
            try
            {   //Check if everything that is required is set
                if(isset($formData['event'], $formData['language'], $formData['price'], $formData['quantity'], $formData['location'], $formData['startTime'], $formData['duration'], $formData['date'], $formData['guide']))
                {   //Check if somethings are not empty
                    if(!empty($formData['event']) && !empty($formData['language']) && !empty($formData['price']) && !empty($formData['quantity']) && !empty($formData['location']) && !empty($formData['startTime']) && !empty($formData['duration']) && !empty($formData['date']) && !empty($formData['guide']))
                    {   //Check if something are numbers
                        if(is_numeric($formData['price']) && is_numeric($formData['quantity']))
                        {   //Add historicevent to database
                            if($this->model->addHistoricEvent($formData, $eventID))
                            {   //Go back to programme 
                                header('Location: programme?page=Historic');
                            }
                            else {  //Throw exception if not added to daatabase
                                throw new Exception('Adding historic event failed');
                            }
                        }
                        else { //Show error if not number
                            $error['basicError'] = 'You did not fill in a number (event, price or quantity)';
                        }
                    }
                    else { //Show error if something is empty
                        $error['basicError'] = 'You left (guide, event, price, quantity or language) empty';
                    }
                }
                else { //Show error if not everything is filled in
                    $error['basicError'] = 'Not everything is filled in';
                }
                //Return error
                return $error;
            }
            catch (Exception $e) {
                //Show thrown exception
                echo $e->getMessage();
            }
        }

        //Function to edit historicevent
        public function doEditHistoricEvent(array $formData, int $eventID, int $ticketID)
        {
            try
            {   //Check if everything that is required is set
                if(isset($formData['event'], $formData['language'], $formData['price'], $formData['quantity'], $formData['location'], $formData['startTime'], $formData['duration'], $formData['date'], $formData['guide']))
                {   //Check if somethings are not empty
                    if(!empty($formData['event']) && !empty($formData['language']) && !empty($formData['price']) && !empty($formData['quantity']) && !empty($formData['location']) && !empty($formData['startTime']) && !empty($formData['duration']) && !empty($formData['date']) && !empty($formData['guide']))
                    {   //Check if something are numbers
                        if(is_numeric($formData['price']) && is_numeric($formData['quantity']))
                        {   //edit danceevent in database
                            if($this->model->editHistoricEvent($formData, $eventID, $ticketID))
                            {   //Go back to programme 
                                header('Location: programme?page=Historic');
                            }
                            else {  //Throw exception if not edited to daatabase
                                throw new Exception('Edit historic event failed');
                            }
                        }
                        else {  //Show error if not number
                            $error['basicError'] = 'You did not fill in a number (event, price or quantity)';
                        }
                    }
                    else {  //Show error if something is empty
                        $error['basicError'] = 'You left (guide, event, price, quantity or language) empty';
                    }
                }
                else {  //Show error if not everything is filled in
                    $error['basicError'] = 'Not everything is filled in';
                }
                //return error
                return $error;
            }
            catch (Exception $e) {
                //show thrown exception
                echo $e->getMessage();
            }
        }

        //Function to get historicevent
        public function doGetHistoricEvent(int $ticketID)
        {
            try {
                //Get result from databse
                if($result = $this->model->getHistoricEvent($ticketID))
                {
                    //Fetch row and check if row is not null
                    $row = mysqli_fetch_assoc($result);
                    if($row == null)
                    {   //Go back to programme
                        header('Location: /programme?page=Historic');
                    }
                    else
                    {   //Make historicModel and set historicevent
                        $event = new historicModel();
                        $event->setHistoricEvent($row['name'], $row['time'], $row['date'], $row['locationID'], $row['price'], $row['quantity'], $row['duration'], $row['guide'], $row['language']);
                        //Return historicevent
                        return $event;
                    }
                }
                else 
                {
                    //Exception if it did not get the danceEvent
                    throw new Exception('Getting dance event failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage;
            }
        }
    }