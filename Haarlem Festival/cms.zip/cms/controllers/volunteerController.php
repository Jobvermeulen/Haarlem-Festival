<?php
    class volunteerController extends baseController
    {
        private $model;

        //constructor
        public function __construct(volunteerModel $model)
        {
            $this->model = $model;
        }

        //Function to get volunteers
        public function doGetVolunteers()
        {
            try {
                //Get result from database
                if($result = $this->model->getAllVolunteers())
                {
                    $volunteers = array();
                    foreach($result as $row)
                    {
                        $volunteer = new volunteerModel();
                        $volunteer->setVolunteer($row['userID'], $row['username'], $row['email']);
                        $volunteers[] = $volunteer;
                    }
                    return $volunteers;
                }
                else 
                {
                    //Exception if it did not get the volunteers
                    throw new Exception('Getting volunteers failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }

        //Function to add volunteer
        public function doAddVolunteer($form)
        {
            try {
                //Check if everything is set
                if(isset($form['username'], $form['email'], $form['password']))
                {   //Check if nothing is empty
                    if(!empty($form['username']) && !empty($form['email']) && !empty($form['password'])) 
                    {   
                        //Check if mail has the right pattern
                        if(preg_match("/^[^@\s<&>]+@([-a-z0-9]+\.)+[a-z]{2,}$/i", $form['email'])) {
                            //Do existence check on username and email
                            $existence = new existenceModel();
                            $error['username'] = $existence->checkUsername($form['username']);
                            $error['email'] = $existence->checkEmail($form['email']);
                            //Check error username and email existence check
                            if(empty($error['username']) && empty($error['email']))
                            {
                                $password = hash('sha256', $form['password']);
                                //Get result from database
                                if($lastID = $this->model->addVolunteer($form['username'], $form['email'], $password))
                                {
                                    $error = $this->doChangeRolesVolunteer($lastID, $form);
                                    if($error == 'completed')
                                    {
                                        header('Location: /volunteers');
                                    }
                                    else {
                                        //Delete volunteer because no roles are selected and than when error shows it will say user already exists
                                        $this->model->deleteVolunteer($lastID);
                                        return $error;
                                    }
                                }
                                else 
                                {
                                    //Exception if it did not get the volunteers
                                    throw new Exception('Adding volunteer failed!');
                                }
                            }
                        }
                        else {
                            $error['basicError'] = 'Email is not valid!';
                        }
                    }
                    else {
                        $error['basicError'] = 'You left something empty!';
                    }
                }
                else {
                    $error['basicError'] = 'Not everything is filled in!';
                }
                return $error;
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }

        //Function to get volunteer by id
        public function doGetVolunteerByID(int $volunteerID)
        {
            try {
                //Get result from database
                if($result = $this->model->getVolunteerByID($volunteerID))
                {
                    //Check if rows is bigger than 1
                    if($result->num_rows > 0)
                    {   //Creata array and set some variables
                        $roles = array();
                        $userID = $username = $email = '';
                        $round = 0;
                        //Foreach row in result loop
                        foreach($result as $row)
                        {   //if row is null go to volunteers page
                            if($row == null)
                            {
                                header('Location: /volunteers');
                            }
                            //Add role to array
                            $roles[] = $row['rolename'];

                            //Check if $rounds is bigger than 0
                            if($round > 0) {
                                //Add 1 to round
                                $round++;
                            }
                            else {
                                //Set userID for first time and add 1 to round
                                $userID = $row['userID'];
                                $username = $row['username'];
                                $email = $row['email'];
                                $round++;
                            }
                        }
                        //create volunteerModel and set volunteer
                        $volunteer = new volunteerModel();
                        $volunteer->setVolunteer2($userID, $username, $email, $roles);
                        //Return volunteer
                        return $volunteer;
                    }
                    else {
                        //Go to volunteer page
                        header('Location: /volunteers');
                    }
                }
                else {
                    //Throw exception if getting failed
                    throw new Exception('Getting volunteer by ID failed');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }

        //Function to update volunteer
        public function doUpdateVolunteerByID(int $volunteerID, array $form, string $oldEmail)
        {
            try {  
                //Check if everything is set
                if(isset($form['email'], $form['password']))
                {   //Check if nothing is empty
                    if(!empty($form['email']) && !empty($form['password'])) 
                    {  
                        $password = $form['password'];
                        //Check if password is changed
                        if($password != 'fakepass') 
                        {
                            //Hash new password
                            $password = hash('sha256', $password);
                        }
                        else 
                        {
                            //Set password to empty
                            $password = '';
                        }
                        if($form['email'] != $oldEmail)
                        {
                            //Check if mail has the right pattern
                            if(preg_match("/^[^@\s<&>]+@([-a-z0-9]+\.)+[a-z]{2,}$/i", $form['email'])) {
                                //Do existence check on username and email
                                $existence = new existenceModel();
                                $error['email'] = $existence->checkEmail($form['email']);
                                //Check error email existence check
                                if(!empty($error['email']))
                                {
                                    return $error;
                                }
                            }
                            else {
                                $error['basicError'] = 'Email is not valid!';
                            }
                        }
                        //Get result from database
                        if($this->model->updateVolunteerByID($volunteerID, $form['email'], $password))
                        {
                            $error = $this->doChangeRolesVolunteer($volunteerID, $form);
                            if($error == 'completed')
                            {
                                header('Location: /volunteers');
                            }
                        }
                        else 
                        {
                            //Exception if it did not get the volunteers
                            throw new Exception('Updating volunteer failed!');
                        }
                    }
                    else {
                        $error['basicError'] = 'You left something empty!';
                    }
                }
                else {
                    $error['basicError'] = 'Not everything is filled in!';
                }
                return $error;
            }
            catch (Exception $e){
                //Show error message
                echo $e->getMessage();
            }
        }

        //Function to change volunteer roles
        public function doChangeRolesVolunteer(int $volunteerID, array $form)
        {
            try {    
                //Create array
                $addRoles = array();
                //Foreach role check if is set and add to array
                if(isset($form['jazz']))
                {
                    $addRoles['jazz'] = $form['jazz'];
                }
                if(isset($form['dance']))
                {
                    $addRoles['dance'] = $form['dance'];
                }
                if(isset($form['historic']))
                {
                    $addRoles['historic'] = $form['historic'];
                }
                if(isset($form['food']))
                {
                    $addRoles['food'] = $form['food'];
                }
                //Check if addroles is not equal to 0
                if(count($addRoles) != 0)
                {   //First remove alle roles
                    if($this->model->removeRolesVolunteer($volunteerID))
                    {   //Second add all new roles
                        if($this->model->addRolesVolunteer($volunteerID, $addRoles))
                        {   //Return completed
                            return 'completed';
                        }
                        else {
                            //Exception if changing roles volunteer did not work
                            throw new Exception('Could not add roles user. Try again later!');
                        }
                    }
                    else {
                        //Exception if changing roles volunteer did not work
                        throw new Exception('Could not delete roles user. Try again later!');
                    }
                }
                else {
                    //Error if there are 0 roles selected
                    $error['basicError'] = 'Select atleast one role for the volunteer';
                    return $error;
                }
            }
            catch (Exception $e){
                //Show error message
                echo $e->getMessage();
            }
        }

        //Function to delete volunteer
        public function doDeleteVolunteer($volunteerID)
        {
            try {             
                    //Try to delete volunteer
                    if($this->model->deleteVolunteer($volunteerID)) {
                        //Go to searchUser page if volunteer is deleted
                        header('Location: volunteers');
                    }
                    else {
                        //Exception if deleting volunteer did not work
                        throw new Exception('Could not delete user. Try again later!');
                    }
            }
            catch (Exception $e){
                //Show error message
                echo $e->getMessage();
            }
        }


        //Function to search volunteer
        public function searchVolunteer(array $form)
        {
            try
            {
                //Create error/volunteers array
                $error = array();
                $volunteers = array();
                //Check if choose is set
                if(isset($form['choose']))
                {   //Check if choose is username
                    if($form['choose'] == 'username')
                    {   //Check if username is set and not empty
                        if(isset($form['username']) && !empty($form['username']))
                        {   //Get result from db
                            $result = $this->model->getVolunteerByUsername($form['username']);
                            //Check if result is 1 row
                            if($result->num_rows == 1)
                            {   //Fetch row and set volunteer and add to array
                                $row = mysqli_fetch_assoc($result);
                                $volunteer = new volunteerModel();
                                $volunteer->setVolunteer($row['userID'], $row['username'], $row['email']);
                                $volunteers[] = $volunteer;
                            }
                            else { //Error if result is not 1 row
                                $error['noUserError'] = 'No user found with this username: ' . $form['username'];
                            }
                        }
                        else {  //Error if not everything is filled in
                            $error['basicError'] = 'Not everything is filled in!';
                        }
                    }   //Check if choose is roles
                    elseif ($form['choose'] == 'roles')
                    {   //Check if role is set and numeric
                        if(isset($form['roleSelect']) && is_numeric($form['roleSelect']))
                        {   //Get result from sb
                            $result = $this->model->getVolunteerByRole($form['roleSelect']);
                            //Check if result is bigger than 0
                            if($result->num_rows > 0)
                            {   //Foreach row in result loop
                                foreach($result as $row)
                                {   //set volunteer and add to array
                                    $volunteer = new volunteerModel();
                                    $volunteer->setVolunteer($row['userID'], $row['username'], $row['email']);
                                    $volunteers[] = $volunteer;
                                }
                            }
                            else {  //Error if no user with that role
                                $error['noUserError'] = 'No user found with this role';
                            }
                        }
                        else { //Error if not everything is filled in
                            $error['basicError'] = 'Not everything is filled in!';
                        }
                    }
                }
                else { //Error if not everything is filled in
                    $error['basicError'] = 'Not everything is filled in!';
                }
                //Check if error is null
                if($error == null)
                {   //Return volunteers
                    return $volunteers;
                }
                else {
                    //Return error
                    return $error;
                }
            }
            catch (Exception $e){
                //Get exception messages
                echo $e->getMessage();
            }
        }
    }
