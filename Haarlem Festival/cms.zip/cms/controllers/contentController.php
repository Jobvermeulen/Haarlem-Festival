<?php 
    class contentController extends baseController
    {
        private $model;

        public function __construct(contentModel $model)
        {
            $this->model = $model;
        }

        //Function to get all text content
        public function doGetTextContent(string $pageName)
        {
            try {
                //Get result from database
                if($result = $this->model->getTextContent($pageName))
                { 
                    //Create array
                    $textContent = array();
                    //Foreach row in result loop
                    foreach($result as $row)
                    {   //create contentModel and set content
                        $text = new contentModel();
                        $text->setText($row['textID'], $row['name'], strip_tags($row['text']));
                        //Add text to array
                        $textContent[] = $text;
                    }
                    //Return array
                    return $textContent;
                }
                else 
                {
                    //Exception if it did not get the text
                    throw new Exception('Getting textContent failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }

        //Function to get text by ID
        public function doGetTextContentByID(int $textID, string $page)
        {
            try {
                //Get result from database
                if($result = $this->model->getTextContentByID($textID))
                { 
                    //Fetch row and check if row is null
                    $row = mysqli_fetch_assoc($result);
                    if($row == null)
                    {   //Go to content overview page
                        header('Location: content?page=' . $page);
                    }
                    else {
                        //create contentModel and set content
                        $text = new contentModel();
                        $text->setText($row['textID'], $row['name'], $row['text']);
                    }
                    //Return text
                    return $text;
                }
                else 
                {
                    //Exception if it did not get the text
                    throw new Exception('Getting textContent by ID failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }

        //Function to update text content
        public function doUpdateTextContent(array $form, int $textID, string $page)
        {
            try {
                //Check if everything is set  
                if(isset($form['text']) && !empty($form['text'])) {       
                    //Try to update text content
                    if($this->model->updateTextContent($form['text'], $textID)) {
                        header('Location: /content?page=' . $page);
                    }
                    else {
                        //Exception if updating volunteer did not work
                        throw new Exception('Could not update text. Try again later!');
                    }
                }
                else {
                    $error['basicError'] = 'You left the textarea empty!';
                    return $error;
                }
            }
            catch (Exception $e) {
                echo $e->getMessage();
            }
        }

        public function doGetImagesContent(string $pageName)
        {
            try {
                //Get result from database
                if($result = $this->model->getImageContent($pageName))
                { 
                    //Create array
                    $images = array();
                    //Foreach row in result loop
                    foreach($result as $row)
                    {   //create contentModel and set image
                        $image = new contentModel();
                        $image->setImage($row['imageID'], $row['name'], $row['image'], $row['altText']);
                        //Add image to array
                        $images[] = $image;
                    }
                    //Return array
                    return $images;
                }
                else 
                {
                    //Exception if it did not get the images
                    throw new Exception('Getting images failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }

        //Function to get image by ID
        public function doGetImageContentByID(int $imageID, string $page)
        {
            try {
                //Get result from database
                if($result = $this->model->getImageContentByID($imageID))
                { 
                    //Fetch row and check if row is null
                    $row = mysqli_fetch_assoc($result);
                    if($row == null)
                    {   //Go to content overview page
                        header('Location: content?page=' . $page);
                    }
                    else {
                        //create contentModel and set content
                        $image = new contentModel();
                        $image->setImage($row['imageID'], $row['name'], $row['image'], $row['altText']);
                    }
                    //Return text
                    return $image;
                }
                else 
                {
                    //Exception if it did not get the text
                    throw new Exception('Getting imageContent by ID failed!');
                }
            }
            catch (Exception $e) {
                //Get exception messages
                echo $e->getMessage();
            }
        }

        //Function to update image content
        public function doUpdateImageContent(array $form, int $imageID, string $page, array $image, string $oldPath)
        {
            try {
                $path;
                $error = array();
                //Check if everything is set  
                if(isset($form['altText'], $image) && !empty($form['altText']) && !empty($image)) { 
                    if($image['error'] == 4)
                    {
                        $path = $oldPath;
                    }  
                    else {
                        //Upload image
                        $error = $this->uploadFile($image, 'images/uploads/');
                        $path = 'images/uploads/' . $image['name'];
                        if($error != 'completed')
                        {
                            return $error;
                        }
                    }
                    //Try to update image content
                    if($this->model->updateImageContent($path, $imageID, $form['altText'])) {
                        header('Location: /content?page=' . $page);
                    }
                    else {
                        //Exception if updating i image not work
                        throw new Exception('Could not update image. Try again later!');
                    }
                }
                else {
                    $error['basicError'] = 'You left the alttext empty!';
                    return $error;
                }
            }
            catch (Exception $e) {
                echo $e->getMessage();
            }
        }

        //Function to upload a image
        public function uploadFile(array $picture, string $path) 
        {
            //Set destination map
            $map = '/home/thomaur292/domains/haarlem-festival.nl/private_html/' . $path;
            //Get data from image
            $fileName = $map . basename($picture['name']);
            $fileTemp = $picture['tmp_name'];
            $fileSize = $picture["size"];
            $fileType = strtolower(pathinfo($fileName,PATHINFO_EXTENSION));
            // Check if image file is a actual image or fake image
                $check = getimagesize($fileTemp);
                if($check !== false) {
                    //Check if image name already exists
                    if (file_exists($fileName)) {
                        $error['basicError'] = 'Sorry, file already exists. Try another file name';
                        return $error;
                    }
                    //Check if image is not bigger than 2MB
                    elseif ($fileSize > 2097152) {
                        $error['basicError'] = 'File is bigger than 2MB!';
                        return $error;
                    }  
                    //Check if image has the right extension
                    elseif ($fileType != 'jpg' && $fileType != 'png' && $fileType != 'jpeg') {
                        $error['basicError'] = 'Please use a JPG or PNG file. Not GIF or any other type';
                        return $error;
                    }
                    //Upload the file
                    elseif(move_uploaded_file($fileTemp, $fileName)) {
                        $error = 'completed';
                        return $error;
                    } 
                    else { //Give error if uploading goes wrong
                        $error['basicError'] = 'Sorry, there was an error uploading your file.';
                        return $error;
                    }
                } 
                else { //Error when file is not an image
                    $error['basicError'] = 'File is not an image!';
                    return $error;
            }
        }
    }