<?php  
    class baseController
    {
        //Function to load the views
        public static function createView(string $viewName) 
        {
            require_once('views/'.$viewName. 'View.php');
        }

        //Function to load the menu
        public function loadMenu($active) {
            //Check if roles is set in session
            if(isset($_SESSION['roles']))
            {
                //check if user has admin role
                if($_SESSION['roles'][0] == 'Admins')
                {   //Include admin nav
                    include('views/modules/navAdmin.php');
                }
                else 
                {   //include multirolenac
                    include('views/modules/navMultiRole.php');
                }
            }
        }

        //Function to load the css files
        public function loadHead(string $title='') {
            include('views/modules/head.php');
        }

        //Function to check if someone is signedin 
        public function checkSignedIn()
        {
            //Check if session does not exsist
            if(!$_SESSION['signedIn'])
            {   //Go to login page
                header('Location: /');
            }
        }

        //Function to check if admin role is active
        public function checkAdminRole()
        {
            //Set roles in $roles array and make bool isAdmin
            $roles = $_SESSION['roles'];
            $isAdmin = false;
            //Foreach that loops through roles array
            foreach($roles as $role)
            {   //If role is Admins than set bool to true
                if($role == 'Admins')
                {
                    $isAdmin = true;
                }
            }   //Go to error page if bool is false
            if(!$isAdmin)
            {
                header('Location: /error403');
            }
        }

        //Check if givenrole is active on user or admin role
        public function checkRole($givenRole)
        {
            //Set roles in $roles array and make bool isCorrect
            $roles = $_SESSION['roles'];
            $isCorrect = false;
            //Foreach that loops through roles array
            foreach($roles as $role)
            {   //If role is equal to admin role or is  than set bool to true
                if($role == $givenRole)
                {
                    $isCorrect = true;
                }
                elseif($role == 'Admins')
                {
                    $isCorrect = true;
                }
            }   //Go to error page if bool is false
            if(!$isCorrect)
            {
                header('Location: /error403');
            }
        }

        public function showCounter(string $counterName)
        {
            // Add correct path to counter file.
            $path = 'counters/'.$counterName.'Counter.txt';

            // Opens counter to read the number of hits.
            $file  = fopen( $path, 'r' );
            $count = fgets( $file, 1000 );
            fclose( $file );

            //return count
            return $count;
        }
    }