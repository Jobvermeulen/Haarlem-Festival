<?php
//Get error messages
error_reporting(E_ALL); 
ini_set('display_errors', 1);

//Require routes file
require_once('routes.php');

//Autoload for loading all files
function __autoload($className) {
    if (file_exists('./models/'.$className.'.php')) {
        require_once './models/'.$className.'.php';
    } else if(file_exists('./models/eventModels/'.$className.'.php')) {
        require_once './models/eventModels/'.$className.'.php';
    } else if(file_exists('./controllers/'.$className.'.php')) {
        require_once './controllers/'.$className.'.php';
    } else if(file_exists('./controllers/eventControllers/'.$className.'.php')) {
        require_once './controllers/eventControllers/'.$className.'.php';
    } 
    
}

