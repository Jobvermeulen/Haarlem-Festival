<?php
    class contentModel
    {
        public $contentID;
        public $contentName;
        public $contentText;
        public $contentImage;
        public $contentImageAltText;

        //Function to set text
        public function setText(int $id, string $name, string $text)
        {
            $this->contentID = $id;
            $this->contentName = $name;
            $this->contentText = $text;
        }
        //Function to set image
        public function setImage(int $id, string $name, string $image, string $altText)
        {
            $this->contentID = $id;
            $this->contentName = $name;
            $this->contentImage = $image;
            $this->contentImageAltText = $altText;
        }
        //Getter functions
        public function getID()
        {
            return $this->contentID;
        }

        public function getName()
        {
            return $this->contentName;
        }

        public function getText()
        {
            return $this->contentText;
        }

        public function getImage()
        {
            return $this->contentImage;
        }

        public function getAltText()
        {
            return $this->contentImageAltText;
        }

        //Function to get textcontent from database
        public function getTextContent(string $pageName)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            $sql= ' SELECT textID, name, text
                    FROM Content_Text AS CT
                    JOIN Web_Placement AS WP ON CT.web_Placement = WP.placementID 
                    WHERE eventID = (SELECT eventID FROM Events WHERE eventname LIKE ?)';
            
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param('s', $pageName);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Could not get text. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Could notget text. Try again later!');
            }
            
        }
        //Function to get text content by id 
        public function getTextContentByID(int $textID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            //Query
            $sql= ' SELECT textID, name, text
                    FROM Content_Text AS CT
                    JOIN Web_Placement AS WP ON CT.web_Placement = WP.placementID 
                    WHERE textID LIKE ?';
            
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param('i', $textID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Could not get text by id. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Could notget text by id. Try again later!');
            }
            
        }

        //Function to update volunteer in db
        public function updateTextContent(string $text, int $textID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to update the password
            $sql = "UPDATE Content_Text SET text = ?, userID = ? WHERE textID LIKE ?";

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("sii", $text, $_SESSION['userID'], $textID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Updating textcontent failed. Try again later!');
                }
                else {
                    //Get result
                    $result = true;
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('updating textcontent failed. Try again later!');
            }
        }

        //Function to get imagecontent from database
        public function getImageContent(string $pageName)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            $sql= ' SELECT imageID, name, image, altText
                    FROM Content_Images AS CI
                    JOIN Web_Placement AS WP ON CI.placementID = WP.placementID 
                    WHERE eventID = (SELECT eventID FROM Events WHERE eventname LIKE ?)';
            
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param('s', $pageName);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Could not get images. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Could not get images. Try again later!');
            }
            
        }
        //Function to get image by ID from database
        public function getImageContentByID(int $imageID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            $sql= ' SELECT imageID, name, image, altText
                    FROM Content_Images AS CI
                    JOIN Web_Placement AS WP ON CI.placementID = WP.placementID 
                    WHERE imageID LIKE ?';
            
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param('i', $imageID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Could not get image by id. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Could notget image by id. Try again later!');
            }
            
        }

        //Function to create webplacement
        public function createWebPlacement(string $name)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the webplacement
            $sql = "INSERT INTO Web_Placement (name)
                    VALUES (?)";

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("s", $name);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Add WebPlacement failed. Try again later!');
                }
                else {
                    //Get result
                    $lastID = mysqli_insert_id($con);
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Add WebPlacement failed. Try again later!');
            }
            //Return lastID
            return $lastID;
        }

        //Function to add image to db
        public function addImageContent(string $path, int $eventID, int $webPlacementID, string $altText)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the webplacement
            $sql = "INSERT INTO Content_Images (eventID, placementID, image, altText, userID)
                    VALUES (?, ?, ?, ?, ?)";

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("iissi", $eventID, $webPlacementID, $path, $altText, $_SESSION['userID']);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Add ContentImageToDB failed. Try again later!');
                }
                else {
                    //Get result
                    return true;
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Add ContentImageToDB failed. Try again later!');
            }
        }

        //Function to edit image in db
        public function updateImageContent(string $path, int $imageID, string $altText)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the webplacement
            $sql = "UPDATE Content_Images
                    SET image=?, altText=?, userID=?
                    WHERE imageID LIKE ?;";

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("ssii", $path, $altText, $_SESSION['userID'], $imageID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Edit ContentImageToDB failed. Try again later!');
                }
                else {
                    //Get result
                    return true;
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Edit ContentImageToDB failed. Try again later!');
            }
        }
    }