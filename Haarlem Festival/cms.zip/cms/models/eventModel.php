<?php   
    class eventModel 
    {
        //Every event
        public $eventID;
        public $ticketID;
        public $eventName;
        public $description;
        public $notice;
        public $startTime;
        public $date;
        public $duration;
        public $quantity;
        public $price;
        public $locationName;
        public $locationID;

        //Function to set event
        public function setEvent(int $eventID, int $ticketID, string $eventName, $time, $date, $location, $price, $quantity)
        {
            $this->eventID = $eventID;
            $this->ticketID = $ticketID;
            $this->eventName = $eventName;
            $this->startTime = $time;
            $this->date = $date;
            $this->locationName = $location;
            $this->price = $price;
            $this->quantity = $quantity;
        }

        //Getter functions
        public function getEventID()
        {
            return $this->eventID;
        }

        public function getTicketID()
        {
            return $this->ticketID;
        }

        public function getEventName()
        {
            return $this->eventName;
        }

        public function getTime()
        {
            return $this->startTime;
        }

        public function getDuration()
        {
            return $this->duration;
        }

        public function getNotice()
        {
            return $this->notice;
        }
        
        public function getDate()
        {
            return $this->date;
        }

        public function getPrice()
        {
            return $this->price;
        }

        public function getQuantity()
        {
            return $this->quantity;
        }

        public function getLocationName()
        {  
            return $this->locationName;
        }

        public function getLocationID()
        {  
            return $this->locationID;
        }

        //Function to get programme from database
        public function getProgramme(string $pageName)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            $sql= ' SELECT T.eventID, ticketID, T.name AS eventName, time, date, L.name AS locationName, price, quantity
                    FROM Tickets AS T 
                    LEFT JOIN Location AS L ON L.locationID = T.locationID
                    JOIN Events AS E ON T.eventID = E.eventID 
                    WHERE eventname LIKE ?
                    ORDER BY date ASC, time ASC, T.name ASC';
            
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param('s', $pageName);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Could not load programme. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Could not load programme. Try again later!');
            }
            
        }
        
        //Function to delete event from db
        public function deleteEvent(int $ticketID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            //Query
            $sql = 'DELETE FROM Tickets WHERE ticketID LIKE ?;';
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("i", $ticketID);
                //Execute statement
                if($stmt->execute()) 
                {
                    return true;
                }
                else {
                    //Throw exception when execution goes wrong
                    throw new Exception ('deleteEvent failed. Try again later!');
                }
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception ('deleteeEvent failed. Try again later!');
            }
        }
    }