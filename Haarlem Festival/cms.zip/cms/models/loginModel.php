<?php
    class loginModel 
    {
        //Declare variables
        public $username;
        public $password;

        //Constructor that sets username and password
        public function __construct(string $username, string $password) 
        {
            $this->username = $username;
            $this->password = $password;
        }

        //Function to check credentials
        public function checkCredentials() 
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query
            $sql = "SELECT U.userID, R.rolename FROM Users AS U 
                    JOIN Assigned_Roles_User AS AR on U.userID = AR.userID
                    JOIN Roles AS R on AR.roleID = R.roleID
                    WHERE username LIKE ? and password LIKE ?;";
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("ss", $this->username, $this->password);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Loginsystem failed. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Loginsystem failed. Try again later!');
            }
            
        }
    }