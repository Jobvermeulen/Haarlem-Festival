<?php
    class locationModel
    {
        //Location
        public $locationName;
        public $locationID;
        public $zipcode;
        public $streetname;
        public $city;
        
        //Function to set location
        public function setLocation(int $locationID, string $locationName, string $streetname, string $zipcode, string $city)
        {
            $this->locationID = $locationID;
            $this->locationName = $locationName;
            $this->zipcode = $zipcode;
            $this->streetname = $streetname;
            $this->city = $city;
        }

        public function getLocationName()
        {  
            return $this->locationName;
        }

        public function getLocationID()
        {
            return $this->locationID;
        }

        public function getStreetname()
        {
            return $this->streetname;
        }

        public function getZipcode()
        {
            return $this->zipcode;
        }
        //Function to get all locations
        public function getAllLocations(string $pageName)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            $sql= ' SELECT name, locationID, street, zipcode, city 
                    FROM Location 
                    WHERE eventID LIKE (SELECT eventID FROM Events WHERE eventname LIKE ?);';
            
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param('s', $pageName);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Could not load all locations. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Could not load all locations. Try again later!');
            }
        }

        //Function to addLocation
        public function addLocation(string $name, string $street, string $city, string $zipcode, string $url, int $eventID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the webplacement
            $sql = "INSERT INTO Location (eventID, name, street, zipcode, city, url)
                    VALUES (?, ?, ?, ?, ?, ?)";

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("isssss", $eventID, $name, $street, $zipcode, $city, $url);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Add Location failed. Try again later!');
                }
                else {
                    //Get result
                    $lastID = mysqli_insert_id($con);
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Add Location failed. Try again later!');
            }
            //Return lastID
            return $lastID;
        }
    }