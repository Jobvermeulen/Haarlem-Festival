<?php
    class volunteerModel
    {
        //Decalre variables
        public $volunteerID;
        public $username;
        public $email;
        public $roles;

        //Function to set volunteer
        public function setVolunteer(int $volunteerID, string $username, string $email)
        {
            $this->volunteerID = $volunteerID;
            $this->username = $username;
            $this->email = $email;
        }

        //Function to set volunteer with roles
        public function setVolunteer2(int $volunteerID, string $username, string $email, array $roles)
        {
            $this->volunteerID = $volunteerID;
            $this->username = $username;
            $this->email = $email;
            $this->roles = $roles;
        }

        //Getter functions
        public function getUsername()
        {
            return $this->username;
        }

        public function getVolunteerID()
        {
            return $this->volunteerID;
        }

        public function getEmail()
        {
            return $this->email;
        }

        public function getRole($roleName)
        {
            //Set bool to false
            $isAssigned = false;
            //Foreach all roles
            foreach($this->roles as $role)
            {   //If role is roleName
                if($role == $roleName)
                {   //Set bool true
                    $isAssigned = true;
                }
            }
            //Return bool
            return $isAssigned;            
        }

        //Function to get all volunteers
        public function getAllVolunteers()
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            
            //Query
            $sql = "SELECT U.userID, username, email 
                    FROM Users AS U 
                    JOIN Assigned_Roles_User AS AU ON U.userID=AU.userID 
                    JOIN Roles AS R ON AU.roleID = R.roleID 
                    WHERE roleName NOT LIKE 'Admins'
                    GROUP BY U.userID";

            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Execute statment
                if($stmt->execute()){ 
                    //Get result
                    $result = $stmt->get_result();
                    return $result;
                }
                else {
                    //Throw exception if execution goes wrong
                    throw new Exception('Getting volunteers failed!');
                }
            } 
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Getting volunteers failed!');
            }
            
        }

        //Function to add volunteer to db
        public function addVolunteer($username, $email, $password)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the roles
            $sql = "INSERT INTO Users (username, email, password)
                    VALUES (?, ?, ?)";

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("sss", $username, $email, $password);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Add role volunteer failed. Try again later!');
                }
                else {
                    //Get result
                    $lastID = mysqli_insert_id($con);
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Add role volunteer failed. Try again later!');
            }
            //Return lastID
            return $lastID;
        }
        
        //Function to get volunteer by ID
        public function getVolunteerByID($volunteerID)
        {          
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query
            $sql = "SELECT U.userID, username, email, rolename FROM Users AS U 
            JOIN Assigned_Roles_User AS AR ON U.userID = AR.userID 
            JOIN Roles AS R ON R.roleID = AR.roleID
            WHERE U.userID LIKE ?;";
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("i", $volunteerID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Could not load volunteer by ID. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Could not load volunteer by ID. Try again later!');
            }
        }

        //Function to get volunteer by username
        public function getVolunteerByUsername(string $username)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query
            $sql = "SELECT userID, username, email FROM Users
                    WHERE username LIKE ?;";
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("s", $username);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Could not load volunteer by username. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Could not load volunteer by username. Try again later!');
            }
        }

        //Function to get volunteer by role from db
        public function getVolunteerByRole(int $roleID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query
            $sql = "SELECT U.userID, username, email FROM Users AS U
                    JOIN Assigned_Roles_User AS AR on U.userID = AR.userID
                    WHERE AR.roleID LIKE ?;";
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("i", $roleID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Could not load volunteer by role. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Could not load volunteer by role. Try again later!');
            }
        }

        //Function to update volunteer in db
        public function updateVolunteerByID(int $volunteerID, string $email, string $password)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            $sql;

            //Query to update the password 
            //If to select the right query
            if($password != ''){
                $sql = "UPDATE Users SET email = ?, password = ? WHERE userID LIKE ?";
            }
            else {
                $sql = "UPDATE Users SET email = ? WHERE userID LIKE ?";
            }

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Check password to select the right bind parameters
                if($password != '')
                {
                    $stmt->bind_param("ssi", $email, $password, $volunteerID);
                }
                else {
                    $stmt->bind_param("si", $email, $volunteerID);
                }
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Updating volunteer failed. Try again later!');
                }
                else {
                    //Get result
                    $result = true;
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('updating volunteer failed. Try again later!');
            }
        }

        //Function to add roles for volunteer in db
        public function addRolesVolunteer(int $volunteerID, array $roles)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            foreach($roles as $role)
            {
                //Query to insert the roles
                $sql = "INSERT INTO Assigned_Roles_User (userID, roleID)
                        VALUES (?, ?)";

                //Prepare statement and bindparameters
                if($stmt = $con->prepare($sql)) {
                    //Bind parameters
                    $stmt->bind_param("ii", $volunteerID, $role);
                    //Execute statement 
                    if(!$stmt->execute()){ 
                        //Throw exception if execution goes wrong
                        throw new Exception('Add role volunteer failed. Try again later!');
                    }
                    else {
                        //Get result
                        $result = true;
                    }
                }
                else {
                    //Throw exception if prepare statement didn't work
                    throw new Exception('Add role volunteer failed. Try again later!');
                }
            }
            return $result;
        }

        //Function to remove roles from volunteer in db
        public function removeRolesVolunteer(int $volunteerID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the roles
            $sql = "DELETE FROM Assigned_Roles_User
            WHERE userID LIKE ?;";

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("i", $volunteerID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Delete roles volunteer failed. Try again later!');
                }
                else {
                    //Get result
                    $isCompleted = true;
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Delete role volunteer failed. Try again later!');
            }

            return $isCompleted;
        }

        //Function to delete volunteer in db
        public function deleteVolunteer($volunteerID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to delete the volunteer
            $sql = "DELETE FROM Users WHERE userID LIKE ?";

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("i", $volunteerID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Deleting volunteer failed. Try again later!');
                }
                else {
                    //Get result
                    $result = true;
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Deleting volunteer failed. Try again later!');
            }
        }
    }
?>