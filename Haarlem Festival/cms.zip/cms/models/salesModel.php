<?php   
    class salesModel 
    {
        //Variables
        public $customerID;
        public $ticketID;
        public $soldTicketID;
        public $customerName;
        public $customerEmail;
        public $ticketName;
        public $ticketPrice;
        public $ticketQuantity;
        public $soldTickets;
        public $totalBought;
        public $totalPrice;
        public $eventName;

        //Function to set customer
        public function setCustomer(int $customerID, int $quantity, float $price, string $name, string $email)
        {
            $this->customerID = $customerID;
            $this->totalBought = $quantity;
            $this->totalPrice = $price;
            $this->customerName = $name;
            $this->customerEmail = $email;
        }

        //Function to set bought ticket
        public function setBoughtTicket(string $name, string $eventname, float $price, int $quantity, int $ticketID)
        {
            $this->ticketName = $name;
            $this->eventName = $eventname;
            $this->ticketPrice = $price;
            $this->ticketQuantity = $quantity;
            $this->ticketID = $ticketID;
        }

        //Getter functions
        public function getCustomerID()
        {
            return $this->customerID;
        }

        public function getCustomerName()
        {
            return $this->customerName;
        }

        public function getCustomerEmail()
        {
            return $this->customerEmail;
        }

        public function getSoldTicketID()
        {
            return $this->soldTicketID;
        }
        
        public function getTotalBought()
        {
            return $this->totalBought;
        }

        public function getEventName()
        {
            return $this->eventName;
        }

        public function getTotalPrice()
        {
            return $this->totalPrice;
        }

        public function getTicketID()
        {
            return $this->ticketID;
        }

        public function getTicketName()
        {
            return $this->ticketName;
        }

        public function getTicketPrice()
        {
            return $this->ticketPrice;
        }

        public function getTicketQuantity()
        {
            return $this->ticketQuantity;
        }

        //Function to get ticket and customer data from db
        public function getTicketAndCustomerData($pageName='')
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            
            //Query
            $sql = '';
            //Check if pagename is not '' and get query
            if($pageName != '')
            {
                $sql = 'SELECT SUM(ST.quantity) as soldQuantity, SUM(ST.price * ST.quantity) as revenue, COUNT(DISTINCT customerID) as customers,
                            (SELECT SUM(quantity) 
                            FROM Tickets AS T  
                            JOIN Events AS E ON T.eventID = E.eventID 
                            WHERE eventname LIKE ?) as availableQuantity 
                        FROM Sold_Tickets AS ST 
                        JOIN Tickets AS T ON ST.ticketID = T.ticketID 
                        JOIN Events as E on T.eventID = E.eventID 
                        WHERE eventname LIKE ?;';
            }
            else {
                $sql = 'SELECT SUM(ST.quantity) as soldQuantity, SUM(ST.price * ST.quantity) as revenue, COUNT(DISTINCT customerID) as customers,
                            (SELECT SUM(quantity) 
                            FROM Tickets) as availableQuantity 
                        FROM Sold_Tickets AS ST 
                        JOIN Tickets AS T ON ST.ticketID = T.ticketID';
            }

            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Check if pagename is '' and use right bindparameters
                if($pageName != '')
                {
                    //Bind parameters
                    $stmt->bind_param("ss", $pageName, $pageName);
                }
                //Execute statment
                if($stmt->execute()){ 
                    //Get result
                    $result = $stmt->get_result();
                    return $result;
                }
                else {
                    //Throw exception if execution goes wrong
                    throw new Exception('Getting TicketAndCustomerData failed!');
                }
            } 
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Getting TicketAndCustomerData failed!');
            }
        }

        //Function to get weekly ticket and customer data from db
        public function getWeeklyTAndCData($pageName='', $startDate, $endDate)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            
            //Query
            $sql = '';

            //Check if pagename is '' and get query
            if($pageName != '')
            {
                $sql = 'SELECT COUNT(DISTINCT customerID) AS customers, SUM(ST.quantity) as quantity, SUM(ST.price * ST.quantity) AS revenue 
                        FROM Sold_Tickets AS ST 
                        JOIN Tickets AS T ON ST.ticketID = T.ticketID 
                        JOIN Events as E on T.eventID = E.eventID 
                        WHERE timestamp BETWEEN ? AND ? AND eventname LIKE ?;';
            }
            else {
                $sql.= 'SELECT COUNT(DISTINCT customerID) AS customers, SUM(quantity) as quantity, SUM(price * quantity) AS revenue 
                        FROM Sold_Tickets 
                        WHERE timestamp BETWEEN ? AND ?;';
            }

            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Check if pagename is '' and use right bindparameters
                if($pageName != '')
                {
                    //Bind parameters
                    $stmt->bind_param('sss', $startDate, $endDate, $pageName);
                }
                else {
                    //Bind parameters
                    $stmt->bind_param('ss', $startDate, $endDate);
                }
                //Execute statment
                if($stmt->execute()){ 
                    //Get result
                    $result = $stmt->get_result();
                    return $result;
                }
                else {
                    //Throw exception if execution goes wrong
                    throw new Exception('Getting getWeeklyTAndCData failed!');
                }
            } 
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Getting getWeeklyTAndCData failed!');
            }
        }

        //Function to get daily sales form db
        public function getDailySales($pageName='', $startDate, $endDate)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            
            //Query
            $sql = '';

            //Check if pagename is '' and get query
            if($pageName != '')
            {
                $sql = 'SELECT SUM(ST.quantity) AS soldQuantity, CAST(timestamp AS DATE) AS date
                    FROM Sold_Tickets AS ST
                    JOIN Tickets AS T ON ST.ticketID = T.ticketID 
                    JOIN Events as E on T.eventID = E.eventID 
                    WHERE timestamp BETWEEN ? AND ? AND eventname LIKE ?
                    GROUP BY CAST(timestamp AS DATE)';
            }
            else {
                $sql = 'SELECT SUM(quantity) AS soldQuantity, CAST(timestamp AS DATE) AS date
                    FROM Sold_Tickets 
                    WHERE timestamp BETWEEN ? AND ?
                    GROUP BY CAST(timestamp AS DATE)';
            }

            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Check if pagename is '' and use right bindparameters
                if($pageName != '')
                {
                    //Bind parameters
                    $stmt->bind_param('sss', $startDate, $endDate, $pageName);
                }
                else {
                    //Bind parameters
                    $stmt->bind_param('ss', $startDate, $endDate);
                }
                //Execute statment
                if($stmt->execute()){ 
                    //Get result
                    $result = $stmt->get_result();
                    return $result;
                }
                else {
                    //Throw exception if execution goes wrong
                    throw new Exception('Getting dailySallesData failed!');
                }
            } 
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Getting dailySal;esData failed!');
            }
        }

        //Function to get all sales from db
        public function getAllSales(string $pageName='')
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            
            //Query
            $sql = '';

            //Check if pagename is '' and use right query
            if($pageName != '')
            {
                $sql = 'SELECT SUM(ST.quantity) AS quantity, SUM(ST.price * ST.quantity) AS price, C.name, email, C.customerID, soldTicketID
                        FROM Sold_Tickets AS ST 
                        JOIN Customers AS C ON ST.customerID=C.customerID
                        JOIN Tickets AS T ON ST.ticketID=T.ticketID
                        WHERE eventID = (SELECT eventID 
                                        FROM Events 
                                        WHERE eventname LIKE ?)
                        GROUP BY C.customerID';
            }
            else {
                $sql = 'SELECT SUM(ST.quantity) AS quantity, SUM(ST.price * ST.quantity) AS price, C.name, email, C.customerID, soldTicketID
                        FROM Sold_Tickets AS ST 
                        JOIN Customers AS C ON ST.customerID=C.customerID
                        JOIN Tickets AS T ON ST.ticketID=T.ticketID
                        GROUP BY C.customerID';
            }

            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Check if pagename is '' and use right bindparameters
                if($pageName != '')
                {
                    //Bind parameters
                    $stmt->bind_param("s", $pageName);
                }
                //Execute statment
                if($stmt->execute()){ 
                    //Get result
                    $result = $stmt->get_result();
                    return $result;
                }
                else {
                    //Throw exception if execution goes wrong
                    throw new Exception('Getting AllSales failed!');
                }
            } 
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Getting AllSales failed!');
            }
        }

        //Function to get customer sales
        public function getCustomerSales(int $customerID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            
            //Query
            $sql = 'SELECT C.name, email, C.customerID, T.ticketID, T.name, ST.price, ST.quantity, eventname
                    FROM Sold_Tickets AS ST 
                    JOIN Customers AS C ON ST.customerID=C.customerID
                    JOIN Tickets AS T ON ST.ticketID=T.ticketID
                    JOIN Events AS E ON T.eventID=E.eventID
                    WHERE C.customerID LIKE ?';

            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("i", $customerID);
                //Execute statment
                if($stmt->execute()){ 
                    //Get result
                    $result = $stmt->get_result();
                    return $result;
                }
                else {
                    //Throw exception if execution goes wrong
                    throw new Exception('Getting AllSales failed!');
                }
            } 
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Getting AllSales failed!');
            }
        }

        //Function to get customer
        public function getCustomer(int $customerID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            
            //Query
            $sql = 'SELECT SUM(ST.quantity) AS quantity, SUM(ST.price * ST.quantity) AS price, C.name, email, C.customerID, soldTicketID
                        FROM Sold_Tickets AS ST 
                        JOIN Customers AS C ON ST.customerID=C.customerID
                        JOIN Tickets AS T ON ST.ticketID=T.ticketID
                        WHERE C.customerID LIKE ?
                        GROUP BY C.customerID';

            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("i", $customerID);
                //Execute statment
                if($stmt->execute()){ 
                    //Get result
                    $result = $stmt->get_result();
                    return $result;
                }
                else {
                    //Throw exception if execution goes wrong
                    throw new Exception('Getting customer failed!');
                }
            } 
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Getting customer failed!');
            }
        }

        //Function for getting the ticket availebility from db
        public function downloadTicketAvailebility()
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            
            //Query
            $sql = 'SELECT E.eventname, T.name, T.time, T.date, T.price, T.quantity
            FROM Tickets AS T 
            JOIN Events AS E ON T.eventID = E.eventID';

            if($result = mysqli_query($con, $sql))
            {     
                //Get result
                return $result;
            }
            else {
                //Throw exception if execution goes wrong
                throw new Exception('Getting ticket data failed!');
            }
        }

        //Function for getting sales information per day from db
        public function getSalesPerDay()
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query
            $sql = 'SELECT E.eventname, T.name, T.date, ST.timestamp, ST.quantity, ST.price 
            FROM Sold_Tickets AS ST 
            JOIN Tickets AS T ON T.ticketID = ST.ticketID
            JOIN Events AS E ON T.eventID = E.eventID
            ORDER BY ST.timestamp DESC';

            if($result = mysqli_query($con, $sql))
            {     
                //Get result
                return $result;
            }
            else {
                //Throw exception if execution goes wrong
                throw new Exception('Getting ticket data failed!');
            }
        }
    }