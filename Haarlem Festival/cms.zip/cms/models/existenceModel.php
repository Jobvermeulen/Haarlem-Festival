<?php
    class existenceModel
    {
        //Function to check if email exists
        function checkEmail(string $email) 
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            //Query
            $sql = "SELECT email FROM Users WHERE email LIKE ?;";
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("s", $email);
                //Execute statement
                if(!$stmt->execute()){
                    //Throw exception when execution goes wrong
                    throw new Exception('Failed to complete existence check');
                }
                else {
                    //Get results
                    $result = $stmt->get_result();
                }
                //Check if result is 1
                if ($result->num_rows == 1) {
                    return 'Email is already in use!';
                }
                else {
                    return null;
                }
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Failed to complete existence check');
            }
        }

        //Function to check if username exists
        function checkUsername(string $username) 
        { 
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            //Query
            $sql = "SELECT username FROM Users WHERE username LIKE ?;";
            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("s", $username);
                //Execute statement
                if(!$stmt->execute()){
                    //Throw exception when execution goes wrong
                    throw new Exception('Failed to complete existence check');
                }
                else {
                    //Get results
                    $result = $stmt->get_result();
                }
                //Check if result is 1
                if ($result->num_rows == 1) {
                    return 'Username is already in use!';
                }
                else {
                    return null;
                }
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Failed to complete existence check');
            }
        }
    }