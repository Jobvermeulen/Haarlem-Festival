<?php  
    class historicModel extends eventModel
    {
        //historic
        public $tourGuide;
        public $tourLanguage;

        //Function to set historicevent
        public function setHistoricEvent(string $eventName, $time, $date, $location, Float $price, $quantity, $duration, $guide, $language)
        {
            $this->eventName = $eventName;
            $this->startTime = $time;
            $this->date = $date;
            $this->locationID = $location;
            $this->price = $price;
            $this->quantity = $quantity;
            $this->duration = $duration;
            $this->tourGuide = $guide;
            $this->tourLanguage = $language;
        }

        //Getter functions
        public function getLanguage()
        {
            return $this->tourLanguage;
        }

        public function getGuide()
        {
            return $this->tourGuide;
        }

        //Function to add historic event to db
        public function addHistoricEvent(array $formData, int $eventID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the roles
            $sql = "INSERT INTO Tickets (eventID, name, date, time, duration, notice, locationID, price, quantity, tourGuideHistoric, tourLanguageHistoric)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("isssssidiss", $eventID, $formData['event'], $formData['date'], $formData['startTime'], $formData['duration'], $formData['notice'], 
                                                    $formData['location'], $formData['price'], $formData['quantity'], $formData['guide'], $formData['language']);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Add Historic Event failed. Try again later!');
                }
                else {
                    return true;
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Add Historic failed. Try again later!');
            }

        }

        //Function to edit historic event in db
        public function editHistoricEvent(array $formData, int $eventID, int $ticketID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the roles
            $sql = "UPDATE Tickets
                    SET name=?, date=?, time=?, duration=?, tourLanguageHistoric=?, tourGuideHistoric=?, locationID=?, price=?, quantity=?
                    WHERE eventID LIKE ? AND ticketID = ?;";

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("ssssssidiii", $formData['event'], $formData['date'], $formData['startTime'], $formData['duration'], $formData['language'], 
                                    $formData['guide'], $formData['location'], $formData['price'], $formData['quantity'], $eventID, $ticketID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Edit Historic Event failed. Try again later!');
                }
                else {
                    return true;
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Edit Historic Event failed. Try again later!');
            }

        }

        //Function to get historic event from db
        public function getHistoricEvent(int $ticketID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            
            //Query
            $sql = "SELECT name, time, date, duration, artists, locationID, price, quantity, tourLanguageHistoric AS language, tourGuideHistoric AS guide
                    FROM Tickets 
                    WHERE ticketID LIKE ? AND eventID LIKE 1";

            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("i", $ticketID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Could not get historicEvent. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Could not get historicEvent. Try again later!');
            }
        }
    }