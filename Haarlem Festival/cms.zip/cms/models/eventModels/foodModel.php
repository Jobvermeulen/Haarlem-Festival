<?php  
    class foodModel extends eventModel
    {
        //food
        public $type;
        public $stars;
        public $reducedPrice;
        public $image;
        public $imageID;
        public $placementID;

        //Function to set foodevent
        public function setFoodEvent(string $eventName, $time, $date, $location, Float $price, $quantity, $duration, $type, $stars, $reducedPrice, $image, $placementID, $imageID)
        {
            $this->eventName = $eventName;
            $this->startTime = $time;
            $this->date = $date;
            $this->locationID = $location;
            $this->price = $price;
            $this->quantity = $quantity;
            $this->duration = $duration;
            $this->type = $type;
            $this->stars = $stars;
            $this->reducedPrice = $reducedPrice;
            $this->image = $image;
            $this->placementID = $placementID;
            $this->imageID = $imageID;
        }

        //Getter functions
        public function getType()
        {
            return $this->type;
        }

        public function getStars()
        {
            return $this->stars;
        }

        public function getReducedPrice()
        {
            return $this->reducedPrice;
        }

        public function getImage() 
        {
            return $this->image;
        }

        public function getImageID() 
        {
            return $this->imageID;
        }

        public function getPlacementID() 
        {
            return $this->placementID;
        }

        //Function to add foodevent
        public function addFoodEvent(array $formData, int $eventID, $startTime, int $locationID, int $webPlacementID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the roles
            $sql = "INSERT INTO Tickets (eventID, name, date, time, duration, starsFood, typeFood, locationID, price, reducedPrice, quantity, webPlacementID)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("issssisiddii", $eventID, $formData['event'], $formData['date'], $startTime, $formData['duration'], $formData['stars'], 
                                                $formData['food'], $locationID, $formData['price'], $formData['reducedprice'], $formData['quantity'], $webPlacementID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Add Food Event failed. Try again later!');
                }
                else {
                    return true;
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Add FoodEvent failed. Try again later!');
            }

        }

        //Function to edit food event
        public function editFoodEvent(array $formData, int $eventID, int $ticketID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the roles
            $sql = "UPDATE Tickets
                    SET date=?, time=?, duration=?, price=?, reducedPrice=?, quantity=?
                    WHERE eventID LIKE ? AND ticketID LIKE ?";

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("sssddiii", $formData['date'], $formData['startTime'], $formData['duration'], $formData['price'], $formData['reducedprice'], $formData['quantity'], $eventID, $ticketID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Edit Food Event failed. Try again later!');
                }
                else {
                    return true;
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Edit FoodEvent failed. Try again later!');
            }

        }

        //Function to edit all food event sessions
        public function editAllFoodEventSessions(array $formData, int $eventID, string $eventName)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the roles
            $sql = 'UPDATE Tickets
                    SET name=?, starsFood=?, typeFood=?, locationID=?
                    WHERE eventID LIKE ? AND name LIKE ?;';

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("sisiis", $formData['event'], $formData['stars'], $formData['food'], $formData['location'], $eventID, $eventName);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Edit All Resturant Food Sessions failed. Try again later!');
                }
                else {
                    return true;
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Edit All Resturant Food Sessions failed. Try again later!');
            }

        }

        //Function to get food event
        public function getFoodEvent(int $ticketID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            
            //Query
            $sql = "SELECT name, time, date, duration, artists, locationID, price, quantity, typeFood, starsFood, reducedPrice, image, webPlacementID, imageID
                    FROM Tickets AS T
                    JOIN Content_Images AS CI ON T.webPlacementID = CI.placementID
                    WHERE ticketID LIKE ? AND T.eventID LIKE 4";

            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("i", $ticketID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Could not get foodEvent. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Could not get foodEvent. Try again later!');
            }
        }
    }