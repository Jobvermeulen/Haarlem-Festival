<?php  
    class jazzModel extends eventModel
    {
        //jazz
        public $hall;
        public $artists;

        //Function to set jazz event
        public function setJazzEvent(string $eventName, $time, $date, $location, Float $price, $quantity, $hall, $duration, $artists)
        {
            $this->eventName = $eventName;
            $this->startTime = $time;
            $this->date = $date;
            $this->locationID = $location;
            $this->price = $price;
            $this->quantity = $quantity;
            $this->duration = $duration;
            $this->hall = $hall;
            $this->artists = $artists;
        }
        //Getter functions
        public function getHall()
        {
            return $this->hall;
        }

        public function getArtists()
        {
            return $this->artists;
        }

        //Function to add jazz event to db
        public function addJazzEvent(array $formData, string $hall, int $eventID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the roles
            $sql = 'INSERT INTO Tickets (eventID, name, date, time, duration, artists, hallJazz, locationID, price, quantity)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("issssssidi", $eventID, $formData['event'], $formData['date'], $formData['startTime'], $formData['duration'], 
                                                $formData['artist'], $hall, $formData['location'], $formData['price'], $formData['quantity']);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Add Jazz Event failed. Try again later!');
                }
                else {
                    return true;
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Add Jazz Event failed. Try again later!');
            }

        }
        
        //Function to edit jazz event in db
        public function editJazzEvent(array $formData, string $hall, int $eventID, int $ticketID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;

            //Query to insert the roles
            $sql = 'UPDATE Tickets
                    SET name=?, date=?, time=?, duration=?, artists=?, hallJazz=?, locationID=?, price=?, quantity=?
                    WHERE eventID LIKE ? AND ticketID LIKE ?';

            //Prepare statement and bindparameters
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("ssssssidiii", $formData['event'], $formData['date'], $formData['startTime'], $formData['duration'], 
                                                $formData['artist'], $hall, $formData['location'], $formData['price'], $formData['quantity'], $eventID, $ticketID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Edit Jazz Event failed. Try again later!');
                }
                else {
                    return true;
                }
            }
            else {
                //Throw exception if prepare statement didn't work
                throw new Exception('Edit Jazz Event failed. Try again later!');
            }

        }

        //Function to get jazz event from db
        public function getJazzEvent(int $ticketID)
        {
            //Get db connection
            $db = database::getInstance();
            $con = $db->con;
            
            //Query
            $sql = "SELECT name, time, date, duration, artists, hallJazz, locationID, price, quantity, artists 
                    FROM Tickets 
                    WHERE ticketID LIKE ? AND eventID LIKE 2";

            //Prepare statement
            if($stmt = $con->prepare($sql)) {
                //Bind parameters
                $stmt->bind_param("i", $ticketID);
                //Execute statement 
                if(!$stmt->execute()){ 
                    //Throw exception if execution goes wrong
                    throw new Exception('Could not get jazzEvent. Try again later!');
                }
                else {
                    //Get result
                    $result = $stmt->get_result();
                }
                //Return result
                return $result;
            }
            else {
                //Throw exception when prepare statement goes wrong
                throw new Exception('Could not get jazzEvent. Try again later!');
            }
        }
    }
    