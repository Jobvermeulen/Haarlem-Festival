//Cancel message function
function cancelMessage(formID, pageName) {
    if (confirm('Are you sure you want to exit this page without saving the changes?')) {
        window.location.href = "/" + pageName;
    } else {
        //document.getElementById(formID).preventDefault();
    }
}
//Function for delete message
function deleteMessage(formID) {
    if (confirm('Are you sure you want to delete this event?')) {
        document.getElementById(formID).submit();
    } else {
        //document.getElementById(formID).preventDefault();
    }
}
//Function to activate or deactivate input types
function selectVolunteerBy(event) {
    if (event.target.value == 'username')
    {
        document.getElementById('role').style.display = 'none';
        document.getElementById("roleSelect").required = false;
        document.getElementById('username').style.display = 'block';
        document.getElementById("name").required = true;
    }
    else if(event.target.value == 'roles')
    {
        document.getElementById('role').style.display = 'block';
        document.getElementById("roleSelect").required = true;
        document.getElementById('username').style.display = 'none';
        document.getElementById("name").required = false;
    }
}
//Function to disable or enable hall field
function jazzHall(event)
{
    if(event.target.value == 16)
    {
        document.getElementById('hallSelect').disabled = false;
    }
    else {
        document.getElementById('hallSelect').disabled = true;
    }
}
//Function to show new location inputs
function newLocation(event)
{
    if(event.target.value == 'new')
    {
        document.getElementById('location1').style.display = 'block';
        document.getElementById('location2').style.display = 'block';
        document.getElementById('location3').style.display = 'block';
        document.getElementById('locationName').disabled = false;
        document.getElementById('street').disabled = false;
        document.getElementById('zipcode').disabled = false;
        document.getElementById('city').disabled = false;
        document.getElementById('url').disabled = false;
    }
    else {
        document.getElementById('location1').style.display = 'none';
        document.getElementById('location2').style.display = 'none';
        document.getElementById('location3').style.display = 'none';
        document.getElementById('locationName').disabled = true;
        document.getElementById('street').disabled = true;
        document.getElementById('zipcode').disabled = true;
        document.getElementById('city').disabled = true;
        document.getElementById('url').disabled = true;
    }
}
//Function to check
function checkNumber(event) {
    if (input.value < 0) {
        input.setCustomValidity('The number must be 0 or bigger.');
    } else {
        input.setCustomValidity('');
    }
}
//Function to show upload image on the page
function showUploadImage(event) {
    var reader = new FileReader();
    reader.onload = function () {
        var output = document.getElementById('showImage');
        output.src = reader.result;
    }
    reader.readAsDataURL(event.target.files[0]);
}
//Function to calculate the file size and make decision to delete it or keep it
function fileSize(event)
{
    var uploadField = document.getElementById("image");

    uploadField.onchange = function () {
        if (this.files[0].size > 2000000) {
            document.getElementById("showImage").src = '';
            document.getElementById('image').value = '';
            alert("Your image is bigger than 2MB!");
        }
        else {
            showUploadImage(event);
        }
    };
}
//Function to get daily sales chart with Ajax
function getDailySalesChart(page)
{
    var dailySalesChart = document.getElementById('dailySales').getContext('2d');
    $.ajax({
        type: "GET",
        url: '/ajaxDashboard',
        data: 'chart=dailySales&page=' + page,
        dataType: 'json',
        success: function (data) {

            var dates = [];
            var sales = [];

            for(var row in data) {
                dates.push(data[row].date);
                sales.push(data[row].sold);
            }

            var dailySales = new Chart(dailySalesChart, {
                // The type of chart we want to create
                type: 'bar',

                // The data for our dataset
                data: {
                    labels: dates,
                    datasets: [{
                        label: "Sold Tickets",
                        backgroundColor: '#199ED8',
                        borderColor: '#199ED8',
                        data: sales,
                    }]
                },

                // Configuration options go here
                options: {}
            });
        }
    });
}
//Function to get sales availablity with ajax
function getSalesAvailableChart(page)
{
    var dailySalesChart = document.getElementById('soldChart').getContext('2d');
    $.ajax({
        type: "GET",
        url: '/ajaxDashboard',
        data: 'chart=soldAvailable&page=' + page,
        dataType: 'json',
        success: function (data) { 
            var dailySales = new Chart(dailySalesChart, {
                // The type of chart to create
                type: 'doughnut',

                // The data for our dataset
                data: {
                    labels: ["Sold", "Available"],
                    datasets: [{
                        label: "Sold Tickets",
                        backgroundColor: [
                            '#00CC00',
                            '#333'
                        ],
                        borderColor: [
                            '#00CC00',
                            '#333'
                        ],
                            data: [data.sold, data.available],
                    }]
                },

                // Configuration options go here
                options: {}
            });
        }
    });
}

function getSalesTable(event) {
    var page;
    if (event == 'Jazz' || event == 'Dance' || event == 'Food' || event == 'Historic' || event == '' )
    {
        page = event;
    }
    else {
        page = event.target.value;
    }
    $.ajax({
        type: "GET",
        url: '/ajaxSalesTable',
        data: 'page=' + page,
        success: function (data) {
            $('#salesTable').html(data);
        }
    });
}